import mysql.connector as mcon
from dblink import Connector, to_date

def Test_Entry(username, subject, testname, testdate, usermarks, maxmarks):
    link = Connector() 
    try:
        cur = link._establish.cursor()
        cur.execute("Select max(testId) from SST")
        last_id = cur.fetchone()[0]
        test_id = (last_id or 0) + 1
        link.table_entry("SST" , (test_id, username, testname, subject, to_date(testdate), usermarks, maxmarks))
    finally:
        link._close()

def Test_List(username, subject):
    link = Connector()
    try:
        cur = link._establish.cursor()
        cur.execute("Select subject, testname, testdate, usermarks, maxmarks from SST "\
                    f"where username = '{username}' and subject = '{subject}' order by usermarks")
        return tuple(cur.fetchall())
    finally:
        link._close()

def Subject_Graph(username):
    link = Connector()
    try:
        cur = link._establish.cursor()
        cur.execute("Select subject, sum(usermarks) / sum(maxmarks) * 100 as percentage from SST "\
                    f"where username = '{username}' group by subject having sum(maxmarks) > 0 "\
                    "order by percentage desc")
        return tuple((subject, float(percentage)) for subject, percentage in cur.fetchmany(3))
    finally:
        link._close()

def Test_Graph(username):
    link = Connector()
    try:
        cur = link._establish.cursor()
        cur.execute("Select testname, sum(usermarks) / sum(maxmarks) * 100 as percentage from SST "\
                    f"where username = '{username}' group by testname having sum(maxmarks) > 0 "\
                    "order by percentage desc")
        return tuple((testname, float(percentage)) for testname, percentage in cur.fetchmany(3))
    finally:
        link._close()