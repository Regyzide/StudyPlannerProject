from dblink import Connector
TABLE_NAME = "Accounts"

def receive_login(username, password):
    conn = Connector()
    try:
        cur = conn._establish.cursor()
        cur.execute(f"Create table if not exists {TABLE_NAME}(Username varchar(30) primary key, "\
                    "password varchar(30) not null)")
        cur.execute(f"Select Username from {TABLE_NAME} where Username = %s", (username,))
        if cur.fetchone() is not None:
            return {"ok": False, "message": "Username already taken"}
        conn.table_entry(TABLE_NAME,(username,password))
        return None
    finally:
        conn._close()

def authenticate(username, password):
    conn = Connector()
    try:
        cur = conn._establish.cursor()
        cur.execute(f"Select password from {TABLE_NAME} where Username = %s", (username,))
        row = cur.fetchone()                               
    finally:
        conn._close()

    if row is not None and row[0] == password:             
        return {"ok": True}
    return {"ok": False, "message": "Wrong username or password"}    
