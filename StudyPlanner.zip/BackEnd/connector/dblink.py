import mysql.connector as mcon
from datetime import datetime
from pathlib import Path

# <project folder>/Entries/mysqlData.txt, found from this file's own location, so the project folder can be moved anywhere
CREDENTIALS_FILE = Path(__file__).resolve().parents[2] / "Entries" / "mysqlData.txt" 
if not CREDENTIALS_FILE.exists():
    raise FileNotFoundError(f"MySQL login details not found. Create {CREDENTIALS_FILE} "
                            "(second line: user;password;database).")

handle = open(CREDENTIALS_FILE, 'r')
INITIALS = handle.readlines()[1].split(';')

def to_date(value):
    """Reads a date given as YYYY/MM/DD or YYYY-MM-DD (or already a date) and returns a date object."""
    if hasattr(value, "year"):
        return value
    for fmt in ("%Y/%m/%d", "%Y-%m-%d"):
        try:
            return datetime.strptime(str(value).strip(), fmt).date()
        except ValueError:
            pass
    raise ValueError(f"not a valid date: {value!r}")


class Connector:
    def __init__(self, username = INITIALS[0], psw = INITIALS[1], db = INITIALS[2]):
        self._establish = mcon.connect(host = 'localhost', user = username, password = psw, database = db)
        self.username = username
        self.password = psw


    def table_entry(self, table_name: str, element: tuple): #Function that passes one value into a particular table automatically
        cur = self._establish.cursor()
        cur.execute(f"Desc {table_name}")
        data = cur.fetchall()
        PARAMETERES = '(' + ', '.join(row[0] for row in data) + ')'     # e.g. (Username, password)
        placeholders = ', '.join(['%s'] * len(element))      # one %s per value; MySQL fills them in safely
        cur.execute(f"Insert ignore into {table_name} {PARAMETERES} values ({placeholders})", element)
        self._establish.commit()

    def _close(self):
        self._establish.close()






    
            


