import mysql.connector as mcon
from dblink import Connector, to_date
from timer_log import _seconds         # 'HH.MM.SS' / 'HH:MM:SS' 
import re

def Schedule_Entry(username, subject, scheduledtime, scheduleddate, remarks = "No remarks"):
    link = Connector()
    try:
        cur = link._establish.cursor()
        cur.execute("Select max(ScheduleId) from Schedules")
        last_id = cur.fetchone()[0]
        schedule_id = (last_id or 0) + 1
        link.table_entry("Schedules" , (schedule_id, username, subject, scheduledtime, to_date(scheduleddate), remarks))
    finally:
        link._close()

def _split(username):
    """Splits this user's schedules into (incomplete, completed) lists of (subject, date, time, remarks)."""
    link = Connector()
    try:
        cur = link._establish.cursor()
        cur.execute("Select subject, scheduleddate, scheduledtime, remarks from Schedules "\
                    "where username = %s order by scheduleddate, scheduleid", (username,))
        schedules = cur.fetchall()
        cur.execute("Select subject, sessiondate, sum(cast(sessiontime as decimal(12,2))) from Sessions "\
                    "where username = %s group by subject, sessiondate", (username,))
        spent = {(subject.lower(), day): float(total) for subject, day, total in cur.fetchall()}  

        needed, incomplete, completed = {}, [], []            # needed: seconds the schedules so far (per subject and day) add up to
        for subject, day, time_txt, remarks in schedules:
            try:
                seconds = _seconds(time_txt)
            except ValueError:                 # unreadable time: can't be completed, so it isn't passed
                incomplete.append((subject, day, time_txt, remarks))
                continue
            key = (subject.lower(), day)
            needed[key] = needed.get(key, 0) + seconds
            if spent.get(key, 0) < needed[key]:
                incomplete.append((subject, day, time_txt, remarks))
            else:
                completed.append((subject, day, time_txt, remarks))
        return incomplete, completed
    finally:
        link._close()


def Schedule_List(username):
    """The schedules that are not completed yet (they fill the dashboard's first page)."""
    return tuple(_split(username)[0])


def Schedule_Completed(username, subject=None):
    """The completed schedules (they fill the dashboard's third page), only one subject's if subject is given."""
    done = _split(username)[1]
    if subject:
        done = [row for row in done if row[0].lower() == subject.lower()]
    return tuple(done)