import customtkinter as ctk
import matplotlib
from PIL import Image, ImageDraw, ImageFont
from matplotlib import font_manager
from datetime import datetime
from pathlib import Path
from types import SimpleNamespace

# --------------------------------------------------------------------------- paths
ASSETS = Path(__file__).resolve().parent.parent / "Assets"   # StudyPlanner/Assets (this file lives in FrontEnd/)
FONT_DIR = ASSETS / "BarlowFont"

# let matplotlib use the bundled Barlow font for the charts (no install needed)
for _weight in ("Regular", "Medium", "SemiBold"):
    _ttf = FONT_DIR / f"Barlow-{_weight}.ttf"
    if _ttf.exists():
        font_manager.fontManager.addfont(str(_ttf))
matplotlib.rcParams["font.family"] = "Barlow"


# --------------------------------------------------------------------------- design size
DESIGN_W = 1280                      # width the layouts were measured at (reference PNGs)
BASE_W, BASE_H = 1680, 1080         # window design size; the 1280-wide layout sits centred in it
X_OFF = (BASE_W - DESIGN_W) / 2
HEADER_H = 80
CONTENT_DROP = 3                     # the sample places each icon+text group ~3px below centre


# --------------------------------------------------------------------------- colours
def blend(c1: str, c2: str, t: float) -> str:
    """Mix hex colour c1 towards c2 by t (0..1). Used for hover / border shades."""
    a = [int(c1[i:i + 2], 16) for i in (1, 3, 5)]
    b = [int(c2[i:i + 2], 16) for i in (1, 3, 5)]
    return "#" + "".join(f"{round(x + (y - x) * t):02X}" for x, y in zip(a, b))


#Colors from the color pallet that has been provided
SAMPLE_COLOURS = dict(header="#508C9B", bg="#EEEEEE", card="#134B70",
                      text_dark="#201E43", text_light="#EEEEEE")


C = SimpleNamespace(**(SAMPLE_COLOURS))
C.card_hover = blend(C.card, C.text_light, 0.12)
C.card_border = blend(C.card, "#000000", 0.35)
C.header_hover = blend(C.header, C.text_light, 0.25)


# --------------------------------------------------------------------------- image helpers
_ICON_CACHE: dict = {}


def load_icon(filename: str) -> Image.Image:
    """Load an icon, make its background transparent, recolour it and crop to the drawing.

    The supplied icons are opaque (card colour behind light lines), except manage_subject.png
    which already has transparency. Deriving the alpha from brightness keeps the anti-aliased
    edges clean and lets the icon work on any background / palette.
    """
    if filename in _ICON_CACHE:
        return _ICON_CACHE[filename]

    img = Image.open(ASSETS / filename).convert("RGBA")
    if filename == "manage_subject.png":
        alpha = img.getchannel("A")
    else:
        lum = img.convert("L")
        lo = Image.new("RGB", (1, 1), (0x1D, 0x54, 0x6D)).convert("L").getpixel((0, 0))   # bg
        hi = Image.new("RGB", (1, 1), (0xF3, 0xF4, 0xF4)).convert("L").getpixel((0, 0))   # lines
        alpha = lum.point(lambda v: max(0, min(255, round((v - lo) / (hi - lo) * 255))))

    box = alpha.point(lambda v: 255 if v > 20 else 0).getbbox()      # tight crop
    icon = Image.new("RGBA", img.size, C.text_light)
    icon.putalpha(alpha)
    _ICON_CACHE[filename] = icon.crop(box)
    return _ICON_CACHE[filename]


def load_glyph(filename: str, size: int) -> Image.Image:
    """Load a transparent white glyph (play/pause/reset), recolour it and resize to size x size."""
    glyph = Image.open(ASSETS / filename).convert("RGBA")
    icon = Image.new("RGBA", glyph.size, C.text_light)
    icon.putalpha(glyph.getchannel("A"))
    return icon.resize((size, size), Image.LANCZOS)


def parse_date(text: str):
    """Reads a date typed as YYYY/MM/DD or YYYY-MM-DD; raises ValueError if it is neither."""
    for fmt in ("%Y/%m/%d", "%Y-%m-%d"):
        try:
            return datetime.strptime(text, fmt).date()
        except ValueError:
            pass
    raise ValueError(f"not a valid date: {text!r}")


def render_text(lines, weight, size, tracking, color, line_height=1.3, align="left") -> Image.Image:
    """Draw text with real letter-spacing and return a tightly cropped RGBA image.

    size      font size in pixels
    tracking  extra space after each letter, in em (0.1 = 10% of the font size)
    """
    font = ImageFont.truetype(str(FONT_DIR / f"Barlow-{weight}.ttf"), max(1, round(size)))
    track = tracking * size
    widths = [font.getlength(t) + track * (len(t) - 1) for t in lines]
    pad = round(size)
    pitch = line_height * size
    w = round(max(widths)) + 2 * pad
    h = round(pitch * (len(lines) - 1) + size * 1.6) + 2 * pad

    mask = Image.new("L", (w, h), 0)
    draw = ImageDraw.Draw(mask)
    for i, text in enumerate(lines):
        x0 = pad + ((max(widths) - widths[i]) / 2 if align == "center" else 0)
        baseline = pad + size + i * pitch
        for j, ch in enumerate(text):
            draw.text((x0 + font.getlength(text[:j]) + j * track, baseline), ch,
                      font=font, fill=255, anchor="ls")

    mask = mask.crop(mask.getbbox())
    out = Image.new("RGBA", mask.size, color)
    out.putalpha(mask)
    return out


def to_ctk_image(img: Image.Image, dpi: float) -> ctk.CTkImage:
    """Wrap a PIL image so it is shown 1:1 on screen (CTk multiplies the size by dpi)."""
    return ctk.CTkImage(img, size=(img.width / dpi, img.height / dpi))


def symbol_image(kind: str, size: float, thickness: float, ppu: float) -> Image.Image:
    """White '+' or '-' symbol, size x size design px, drawn 4x oversampled for smooth edges."""
    px, k = max(2, round(size * ppu)), 4
    big = Image.new("RGBA", (px * k, px * k), (0, 0, 0, 0))
    d, t, mid = ImageDraw.Draw(big), max(1, round(thickness * ppu * k)), px * k // 2
    d.rectangle((0, mid - t // 2, px * k, mid + t // 2), fill=C.text_light)
    if kind == "plus":
        d.rectangle((mid - t // 2, 0, mid + t // 2, px * k), fill=C.text_light)
    return big.resize((px, px), Image.LANCZOS)
