import customtkinter as ctk
import re
from datetime import date

from pages import Page, place_rect
from config import BASE_H, BASE_W, C, HEADER_H, X_OFF, blend, parse_date, render_text, to_ctk_image
from widgets import HeaderBar, SubjectDropdown, TextButton, entry_font

BOX_BORDER = blend(C.text_dark, "#FFFFFF", 0.4)
HINT = blend(C.text_dark, "#FFFFFF", 0.3)


class LabelledEntry(ctk.CTkFrame):
    """White rounded box with an editable, centred value; the placeholder says what to type."""

    def __init__(self, master, placeholder):
        super().__init__(master, fg_color="#FFFFFF", border_color=BOX_BORDER, border_width=1, corner_radius=8)
        self.entry = ctk.CTkEntry(self, placeholder_text=placeholder, justify="center", fg_color="#FFFFFF",
                                  border_width=0, text_color=C.text_dark, placeholder_text_color=HINT)
        self.entry.place(relx=0.5, rely=0.5, anchor="center", relwidth=0.9, relheight=0.7)

    def get(self) -> str:
        return self.entry.get().strip()

    def set(self, value: str):
        self.entry.delete(0, "end")
        if value:
            self.entry.insert(0, value)
        else:
            self.entry._activate_placeholder()

    def flash(self):
        s = getattr(self, "_s", 1)
        self.configure(border_color=C.card, border_width=max(2, round(3 * s)))
        self.after(400, lambda: self.configure(border_color=BOX_BORDER, border_width=max(1, round(s))))

    def rescale(self, s, ppu):
        self._s = s
        self.configure(corner_radius=round(8 * s), border_width=max(1, round(s)))
        self.entry.configure(font=entry_font(21 * s))


# --------------------------------------------------------------------------- Scheduler Page
class SchedulerPage(Page):
    """Study plan scheduler: choose a subject, type the time, the date and (optionally) remarks.
    schedule() checks the entries, announces them to the back end with
    app.emit() function ; (the controller passes them to schedule_log.Schedule_Entry, which stores them in the database; 
    the dashboard reads them back from there) and returns (subject, time, date, remarks). Empty remarks become "No remarks".
    Returns None if the subject is missing or the time / date is empty or invalid.
    """
    NO_REMARKS = "No remarks"

    def __init__(self, master, app): #constructor
        super().__init__(master)
        self.app = app
        self.subject = None
        self.header = HeaderBar(self, "STUDY PLANNER", on_back=lambda: app.show_page("home"))
        self.header.place(relx=0, rely=0, relwidth=1, relheight=HEADER_H / BASE_H)

        self.dropdown = SubjectDropdown(self, lambda: app.subjects, self._on_subject)
        self.dropdown.place(relx=(239 + X_OFF) / BASE_W, rely=201 / BASE_H, anchor="center")

        self.time_box = LabelledEntry(self, "Suggested time : HH:MM:SS")
        place_rect(self.time_box, 85, 287, 856, 97)
        self.date_box = LabelledEntry(self, "Date : YYYY/MM/DD")
        place_rect(self.date_box, 85, 419, 856, 97)

        self.remarks_label = ctk.CTkLabel(self, text="", fg_color="transparent")
        self.remarks_label.place(relx=(85 + X_OFF) / BASE_W, rely=584 / BASE_H, anchor="w")
        self.remarks = ctk.CTkTextbox(self, fg_color="#FFFFFF", border_color=BOX_BORDER, border_width=1,
                                      corner_radius=8, text_color=C.text_dark, wrap="word")
        self.remarks._textbox.tag_configure("center", justify="center")
        place_rect(self.remarks, 219, 552, 722, 276)

        self.schedule_btn = TextButton(self, "Schedule", self.schedule)
        place_rect(self.schedule_btn, 98, 903, 857, 97)

        # right-hand column: Normalize and Optimize fill in the time, date and remarks with a suggestion
        self.normalize_btn = TextButton(self, "Normalize", self.normalize, size=25)
        place_rect(self.normalize_btn, 1009, 287, 239, 69)
        self.target_box = LabelledEntry(self, "Target %")
        place_rect(self.target_box, 1009, 419, 239, 69)
        self.optimize_btn = TextButton(self, "Optimize", self.optimize, size=25)
        place_rect(self.optimize_btn, 1009, 524, 239, 69)

    # -- remarks helpers
    def _get_remarks(self) -> str:
        return self.remarks.get("1.0", "end-1c").strip()

    def _set_remarks(self, text: str):
        self.remarks.delete("1.0", "end")
        if text:
            self.remarks.insert("1.0", text, "center")

    # -- behaviour
    def _on_subject(self, subject):
        self.subject = subject

    def _suggest(self, event, placeholder, *extra):
        """Fills the time, date and remarks boxes with a suggestion for today: asks the back end with
        app.emit() (it answers (time, remarks), or {"ok": False, "message": ...} when it has too little
        data to suggest anything), else uses the temporary placeholder (None = nothing to fall back on)."""
        replies = self.app.emit(event, self.app.username, self.subject, *extra)
        answer = next((r for r in replies if isinstance(r, (tuple, list)) and len(r) == 2), None)
        refusal = next((r for r in replies if isinstance(r, dict) and r.get("ok") is False), None)
        if answer is None and refusal is not None:             # the back end explains why: show it, suggest nothing
            self.time_box.set("")
            self.date_box.set("")
            self._set_remarks(refusal.get("message", "No suggestion is available."))
            return False
        if answer is None and placeholder is None:
            self._set_remarks("No suggestion is available.")
            return False
        time_txt, remarks = answer or placeholder(self.subject, *extra)
        self.time_box.set(str(time_txt))
        self.date_box.set(date.today().strftime("%Y/%m/%d"))
        self._set_remarks(str(remarks))
        return True

    def normalize(self):
        """Normalize button: suggests the study time and remarks for the chosen subject today
        (planner.normalize.Normalizer, through the controller's normalize_glue)."""
        if self.subject is None:
            self.dropdown.flash()
            return None
        if not self._suggest("normalize", None):
            return None
        return self.time_box.get(), self._get_remarks()

    def optimize(self):
        """Optimize button: suggests the study time and remarks that aim for the target percentage (0-100)
        (planner.target_optimize.Target_Optimizer, through the controller's optimize_glue)."""
        if self.subject is None:
            self.dropdown.flash()
            return None
        try:
            percent = float(self.target_box.get().rstrip("%").strip())
            if not 0 <= percent <= 100:
                raise ValueError
        except ValueError:
            self.target_box.flash()
            return None
        if not self._suggest("optimize", None, percent):
            return None
        return self.time_box.get(), self._get_remarks()

    def schedule(self):
        if self.subject is None:
            self.dropdown.flash()
            return None
        time_txt = self.time_box.get()
        date_txt = self.date_box.get()
        remarks = self._get_remarks() or self.NO_REMARKS       # nothing typed -> "No remarks"

        ok = True
        if not re.fullmatch(r"\d{1,3}[.:]\d{2}[.:]\d{2}", time_txt):
            self.time_box.flash()
            ok = False
        try:
            if parse_date(date_txt) < date.today():            # a schedule can't be set for a day that has passed
                raise ValueError
        except ValueError:
            self.date_box.flash()
            ok = False
        if not ok:
            return None

        entry = (self.subject, time_txt, date_txt, remarks)
        # announce it: (controller -> schedule_log.Schedule_Entry) stores it in the database
        self.app.emit("schedule", self.app.username, self.subject, time_txt, date_txt, remarks)
        self.subject = None                                    # back to a blank form
        self.dropdown.set_selected(None)
        self.time_box.set("")
        self.date_box.set("")
        self.target_box.set("")
        self.remarks.delete("1.0", "end")
        return entry

    def rescale(self, s, ppu):
        super().rescale(s, ppu)
        self.header.rescale(s, ppu)
        self.dropdown.rescale(s, ppu)
        self.time_box.rescale(s, ppu)
        self.date_box.rescale(s, ppu)
        self.target_box.rescale(s, ppu)
        self.normalize_btn.rescale(s, ppu)
        self.optimize_btn.rescale(s, ppu)
        self.remarks.configure(font=entry_font(21 * s), corner_radius=round(8 * s), border_width=max(1, round(s)))
        self.remarks._textbox.tag_configure("center", justify="center")
        img = render_text(["Remarks:"], "SemiBold", 25 * ppu, 0.06, C.text_dark)
        self.remarks_label.configure(image=to_ctk_image(img, ppu / s))
        self.schedule_btn.rescale(s, ppu)
