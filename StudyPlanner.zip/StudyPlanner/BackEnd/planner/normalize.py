import mysql.connector as mcon
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "BackEnd"))         # so `connector.account_log` can be imported
sys.path.insert(0, str(ROOT / "BackEnd" / "connector"))

from connector.dblink import Connector

"""Normalization is done over a period of time. The average data of last 3 most recent tests are evaluated and increment in period of time
for every subject in order to bring it to relative average is calculated so that the user reaches this average by the time the next three tests have gotten over"""

class Normalizer():
    def __init__(self, username, subject):
        self.username = username
        self.subject = subject
        self.overall_percentage = self.Average(self.Fetch_Data()[0])
        self.subject_percentage = float(self.Fetch_Data()[1][2])
        self.total_subject_time = float(self.Fetch_Data()[1][0])
        self.total_subject_sessions = self.Fetch_Data()[1][1]
        self._unit = self.total_subject_time/(self.total_subject_sessions*self.subject_percentage) #Mathematical unit which is time required to increase per percent


    def Fetch_Data(self):
        """Returns a tuple (Subject, Respective subject average percentage) a first nested instance; a second instance (Subject hours, Session count, Average subject percentage)
        where all the three parameteres of the second inner instances are measured for the time span across the last three most recent tests."""

        link = Connector()
        OVERALL_DATA, SUBJECT_DATA = [],[]
        try:
            cur = link._establish.cursor()
            cur.execute("select subject, sum(usermarks)/sum(maxmarks)*100 from"\
                        "(select subject, usermarks, maxmarks,"\
                            "row_number() over (partition by subject order by testdate desc, testid desc) as rn "\
                                f"from sst where username = '{self.username}') t where rn <= 3 group by subject")
            OVERALL_DATA = [i for i in cur.fetchall()]

            cur.execute("Select sum(sessiontime) as Total_Session_Time, count(*) as No_of_Sessions from sessions "\
                        f"where username = '{self.username}' and subject = '{self.subject}' and sessiondate between "\
                            f"(select min(testDate) from (select testDate from sst where username = '{self.username}' "\
                                f"and subject = '{self.subject}' order by testDate desc limit 3) as testDates1) and (select max(testDate) from "\
                                    f"(select testDate from sst where username = '{self.username}' and subject = '{self.subject}' "\
                                        "order by testDate desc limit 3) as testDates2)")
            SUBJECT_DATA = [i for i in cur.fetchall()[0]]

            cur.execute("select sum(usermarks)/sum(maxmarks)*100 from"\
                        "(select subject, usermarks, maxmarks,"\
                            "row_number() over (partition by subject order by testdate desc, testid desc) as rn "\
                                f"from sst where username = '{self.username}' and subject = '{self.subject}') t where rn <= 3 group by subject")
            rows = cur.fetchall()
            SUBJECT_DATA.extend(rows[0] if rows else (None,))

            if not OVERALL_DATA or SUBJECT_DATA[2] is None:     # no tests (the aggregates come back as NULL)
                raise ValueError(f"No test data on {self.subject} to work on. Add the marks of some {self.subject} tests first.")
            if SUBJECT_DATA[0] is None or SUBJECT_DATA[1] == 0:     # no sessions between the last tests
                raise ValueError(f"No study sessions of {self.subject} were logged around your last tests, so a study time can't be suggested yet.")
            if float(SUBJECT_DATA[2]) == 0:     # no time can be tied to a 0% score (it would divide by zero)
                raise ValueError(f"Your average in {self.subject} is 0%, so a study time can't be worked out from it. Add the marks of a better test first.")

            return (tuple(OVERALL_DATA) , tuple([i for i in SUBJECT_DATA]))

        finally:
            link._close()

    def Average(self, instance: tuple) -> float:
        total_percentage = 0
        for subject, percentage in instance:
            total_percentage += float(percentage)

        return total_percentage / len(instance)

    def Time_Suggestion(self):
        return max(0.0, (self.overall_percentage - self.subject_percentage)*self._unit + (self.total_subject_time/self.total_subject_sessions))

    def Remarks(self):
        DIFF = self.overall_percentage - self.subject_percentage
        if DIFF >= 15.0:
            return f"Try spending much more time on {self.subject}, alongside revisiting concepts."
        elif DIFF<15.0 and DIFF>=5:
            return f"Try spending more time on {self.subject} alongside solving more problems."
        elif DIFF<5 and DIFF>=-10:
            return f"Your performance in {self.subject} is relatively optimal. Try revising questions with new approaches of solving problems"
        elif DIFF<-10 and DIFF>=-15:
            return f"Your performance in {self.subject} is above optimal. Try maintaining this while managing other subjects."
        elif DIFF<-15:
            return f"Your performance in {self.subject} is relatively exceptional. Try spending more time with other subjects."
