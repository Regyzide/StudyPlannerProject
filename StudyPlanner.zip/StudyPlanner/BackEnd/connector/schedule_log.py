import mysql.connector as mcon
from dblink import Connector
from timer_log import _seconds         # 'HH.MM.SS' / 'HH:MM:SS' 
import re

def Schedule_Entry(username, subject, scheduledtime, scheduleddate, remarks = "No remarks"):
    link = Connector()
    try:
        cur = link._establish.cursor()
        cur.execute("Select max(ScheduleId) from Schedules")
        last_id = cur.fetchone()[0]
        schedule_id = (last_id or 0) + 1
        link.table_entry("Schedules" , (schedule_id, username, subject, scheduledtime, scheduleddate, remarks))
    finally:
        link._close()

def Schedule_List(username):
    link = Connector()
    try:
        cur = link._establish.cursor()
        cur.execute("Select subject, scheduleddate, scheduledtime, remarks from Schedules "\
                    "where username = %s order by scheduleddate, scheduleid", (username,))
        schedules = cur.fetchall()
        cur.execute("Select subject, sessiondate, sum(cast(sessiontime as decimal(12,2))) from Sessions "\
                    "where username = %s group by subject, sessiondate", (username,))
        spent = {(subject.lower(), day): float(total) for subject, day, total in cur.fetchall()}  

        needed, incomplete = {}, []            # needed: seconds the schedules so far (per subject and day) add up to
        for subject, day, time_txt, remarks in schedules:
            try:
                seconds = _seconds(time_txt)
            except ValueError:                 # unreadable time: can't be completed, so it isn't passed
                incomplete.append((subject, day, time_txt, remarks))
                continue
            key = (subject.lower(), day)
            needed[key] = needed.get(key, 0) + seconds
            if spent.get(key, 0) < needed[key]:
                incomplete.append((subject, day, time_txt, remarks))
        return tuple(incomplete)
    finally:
        link._close()