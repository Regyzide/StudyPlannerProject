import mysql.connector as mcon
from dblink import Connector
from datetime import date
import re

"""
The function used here takes the values that are passed by Glue device which inturn takes the values from the frontend.
The status is controlled by completion of the time assigned which has to be obtained from the schedules table.
"""


def _seconds(text):
    """A ScheduledTime from the schedules table -> seconds. Accepts 'HH.MM.SS' / 'HH:MM:SS' or a plain number of seconds."""
    text = str(text).strip()
    if re.fullmatch(r"\d+[.:]\d{2}[.:]\d{2}", text):
        h, m, s = (int(part) for part in re.split(r"[.:]", text))
        return h * 3600 + m * 60 + s
    return float(text)


def Set_Detail(username, subject, session_time):
    """Store one finished timer session in the sessions table and return its status (1 = the schedule is complete, 0 = not).

    username     : str    who is logged in (from the login / sign-up page)
    subject      : str    subject selected on the timer page
    session_time : float  seconds returned when the timer's reset button was hit
    """
    link = Connector()         #Object used to enter values into the table meant to store timer values
    try:
        cur = link._establish.cursor()
        cur.execute("Select max(SessionId) from Sessions")   #Fetches the last session id ; starts at 1 if there are no previous entries
        last_id = cur.fetchone()[0]
        session_id = (last_id or 0) + 1
        session_date = date.today()

        # status: has the user now spent at least the scheduled time on this subject today?
        cur.execute("Select ScheduledTime from Schedules where Username = %s and Subject = %s and ScheduledDate = %s",
                    (username, subject, session_date))
        scheduled = [_seconds(row[0]) for row in cur.fetchall()]
        cur.execute("Select SessionTime from Sessions where Username = %s and Subject = %s and SessionDate = %s",
                    (username, subject, session_date))
        spent = sum(float(row[0]) for row in cur.fetchall() if row[0] is not None) + session_time   # earlier sessions today + this one
        status = 1 if scheduled and spent >= sum(scheduled) else 0       # 1 = every schedule of the subject today is covered; nothing scheduled -> 0

        link.table_entry("Sessions" , (session_id , username , subject , session_date, status, f"{session_time:.2f}"))  #Inserts an instance into the table by using methods of dblink
        link._establish.commit()
        return status
    finally:
        link._close()
