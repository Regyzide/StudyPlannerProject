import mysql.connector as mcon
from dblink import Connector

def Subject_Entry(username: str, subject:str):
    link = Connector()
    try:
        cur = link._establish.cursor()
        link.table_entry("Subjects", (username,subject))
    finally:
        link._close()

def Subject_Preset(username:str):
    link = Connector()
    try:
        cur = link._establish.cursor()
        link.table_entry("Subjects", (username,"English"))
    finally:
        link._close()

def Subject_Remove(username:str, subject:str):
    link = Connector()
    try:
        cur = link._establish.cursor()
        cur.execute(f"Delete from Subjects where username = '{username}' and SubjectName = '{subject}'")  
        link._establish.commit()
    finally:
        link._close()

def Subject_List(username:str):
    link = Connector()
    try:
        cur = link._establish.cursor()
        cur.execute(f"Select SubjectName from Subjects where Username = '{username}' order by SubjectName")
        return [row[0] for row in cur.fetchall()]
    finally:
        link._close()
