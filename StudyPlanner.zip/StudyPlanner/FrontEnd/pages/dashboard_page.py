import customtkinter as ctk
import math
import re
import time
import tkinter as tk
from PIL import ImageFont
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure

from pages import Page, place_rect
from config import BASE_H, BASE_W, C, FONT_DIR, HEADER_H, X_OFF, render_text, to_ctk_image
from widgets import HeaderBar, SubjectDropdown

# --------------------------------------------------------------------------- Dashboard
def percentage(score: str) -> str:
    """'42/50' -> '84%'. Anything that isn't number/number gives a dash."""
    m = re.fullmatch(r"\s*(\d+(?:\.\d+)?)\s*/\s*(\d+(?:\.\d+)?)\s*", score)
    if not m or float(m[2]) == 0:
        return "—"
    return f"{float(m[1]) / float(m[2]) * 100:.1f}".rstrip("0").rstrip(".") + "%"


BAR_COLOURS = ["#A193FF", "#FEA8A1", "#FFBE70"]    # chart bars, left to right (from the reference)


def wrap_lines(text: str, size_px: float, max_w_px: float, max_lines: int):
    """Greedy word wrap using the Barlow Medium metrics; the last line gets an ellipsis if cut."""
    font = ImageFont.truetype(str(FONT_DIR / "Barlow-Medium.ttf"), max(1, round(size_px)))
    lines, cur = [], ""
    for word in text.split():
        trial = f"{cur} {word}".strip()
        if font.getlength(trial) <= max_w_px or not cur:
            cur = trial
        else:
            lines.append(cur)
            cur = word
    lines.append(cur)
    if len(lines) > max_lines:
        lines = lines[:max_lines]
        while lines[-1] and font.getlength(lines[-1] + "…") > max_w_px:
            lines[-1] = lines[-1][:-1]
        lines[-1] = lines[-1].rstrip() + "…"
    return lines or [""]


class BarChart(tk.Frame):
    """Matplotlib bar chart embedded in Tk, styled like the reference (dotted grid, up to 3 bars).

    The figure keeps matplotlib's own dpi (so Tk resizing just works); font and line sizes are
    scaled by `ppu` (physical px per design px) so the chart grows and shrinks with the window.
    """

    def __init__(self, master, title):
        super().__init__(master, bg=C.bg)
        self.pack_propagate(False)                      # the frame (placed by place_rect) sets the size
        self.title, self.ppu = title, 1.0
        self.labels, self.values, self.ymax = [], [], 100.0
        self.fig = Figure(figsize=(1, 1), facecolor=C.bg)
        self.ax = self.fig.add_subplot(111)
        self.canvas = FigureCanvasTkAgg(self.fig, master=self)
        widget = self.canvas.get_tk_widget()
        widget.configure(bg=C.bg, highlightthickness=0, width=1, height=1)
        widget.pack(fill="both", expand=True)

    def set_data(self, labels, values, ymax):
        self.labels, self.values, self.ymax = list(labels), list(values), ymax
        self.draw_chart()

    def rescale(self, ppu):
        self.ppu = ppu
        self.draw_chart()

    def draw_chart(self):
        ax, grey = self.ax, "#4A5558"
        pt = self.ppu * 72 / self.fig.dpi                  # design px -> matplotlib points
        ax.clear()
        ax.set_facecolor(C.bg)
        n = len(self.values)
        ax.bar(range(n), self.values, width=0.8, color=BAR_COLOURS[:n], zorder=3)
        ax.set_xlim(-0.5, 2.5)
        ax.set_ylim(0, self.ymax)
        ax.set_yticks([self.ymax * i / 5 for i in range(6)])
        ax.set_yticklabels([f"{self.ymax * i / 5:g}" for i in range(6)], fontsize=13 * pt, color=grey)
        ax.set_xticks(range(n))
        ax.set_xticklabels([self._fit(lab) for lab in self.labels], fontsize=13 * pt, color=grey)
        ax.set_xticks([-0.5, 0.5, 1.5, 2.5], minor=True)                    # slot boundaries
        for axis in ("y", "x"):
            ax.grid(True, which="major" if axis == "y" else "minor", axis=axis, linestyle=":",
                    color="#D5D8D8", linewidth=1 * pt, zorder=0)
        ax.tick_params(which="both", length=0, pad=8 * pt)
        for side in ("top", "right", "left"):
            ax.spines[side].set_visible(False)
        ax.spines["bottom"].set_color("#888E90")
        ax.spines["bottom"].set_linewidth(1 * pt)
        ax.set_xlabel(self.title, fontsize=18 * pt, fontweight=600, color=C.text_dark, labelpad=16 * pt)
        self.fig.subplots_adjust(left=48 / 580, right=573 / 580, top=1 - 18 / 400, bottom=1 - 313 / 400)
        self.canvas.draw_idle()

    @staticmethod
    def _fit(label, limit=24):
        """Long names get an ellipsis so neighbouring labels don't collide."""
        return label if len(label) <= limit else label[:limit - 1].rstrip() + "\u2026"

class DataRow(ctk.CTkFrame):
    """One table row of centred cells (the first cell is left-aligned, as in the reference)."""

    ROW_H = 91

    def __init__(self, master, values, s, ppu, table_w):
        """values: plain strings, or ("note", text) for wrapped small text."""
        super().__init__(master, fg_color="transparent", corner_radius=0, height=round(self.ROW_H * s))
        n = len(values)
        col_w = table_w / n
        for i, value in enumerate(values):
            kind, content = value if isinstance(value, tuple) else ("text", value)
            anchor = "center"
            if kind == "note":
                img = render_text(wrap_lines(content, 14 * ppu, (col_w - 40) * ppu, 4), "Medium", 14 * ppu,
                                  0.02, C.text_dark, line_height=1.3)
                anchor = "w"
            else:
                size = 22
                while size > 12:                                  # shrink long text to fit its column
                    img = render_text([content], "Medium", size * ppu, 0.03, C.text_dark)
                    if img.width <= (col_w - 40) * ppu:
                        break
                    size -= 1
            lab = ctk.CTkLabel(self, text="", fg_color="transparent", image=to_ctk_image(img, ppu / s))
            if i == 0 and kind == "text":
                lab.place(relx=32 / table_w, rely=0.5, anchor="w")
            elif anchor == "w":
                lab.place(relx=(i + 20 / col_w) / n, rely=0.5, anchor="w")
            else:
                lab.place(relx=(i + 0.5) / n, rely=0.5, anchor="center")
        line = max(1, round(s))
        for i in range(1, n):
            tk.Frame(self, bg="#C8CCCC").place(relx=i / n, rely=0, relheight=1, width=line)
        tk.Frame(self, bg="#C8CCCC").place(relx=0, rely=1, anchor="sw", relwidth=1, height=line)


class ScrollTable(ctk.CTkFrame):
    """Bordered table with a fixed header row and a scrollable body (empty until set_rows)."""

    HEAD_H = 83

    def __init__(self, master, headers, rect):
        super().__init__(master, fg_color="transparent", border_color="#000000", border_width=3,
                         corner_radius=0)
        self.headers, self.n = headers, len(headers)
        self.w, self.h = rect[2], rect[3]
        self.rows_data, self._s, self._ppu = [], None, 1.0

        self.head_labels = []
        for i in range(self.n):
            lab = ctk.CTkLabel(self, text="", fg_color="transparent")
            lab.place(relx=(i + 0.5) / self.n, rely=self.HEAD_H / 2 / self.h, anchor="center")
            self.head_labels.append(lab)
        tk.Frame(self, bg="#9AA0A2").place(relx=0, rely=self.HEAD_H / self.h, relwidth=1, height=2)
        self.head_divs = [tk.Frame(self, bg="#C8CCCC") for _ in range(self.n - 1)]
        for i, div in enumerate(self.head_divs, 1):
            div.place(relx=i / self.n, rely=0, relheight=self.HEAD_H / self.h, width=2)

        # body is inset a few design px so the black border stays visible around it
        self.body = ctk.CTkScrollableFrame(self, fg_color=C.bg, corner_radius=0)
        self.body.place(relx=4 / self.w, rely=(self.HEAD_H + 2) / self.h,
                        relwidth=(self.w - 8) / self.w, relheight=(self.h - self.HEAD_H - 6) / self.h)

    def visible_rows(self) -> int:
        return int((self.h - self.HEAD_H) // DataRow.ROW_H)

    def overflows(self) -> bool:
        return len(self.rows_data) > self.visible_rows()

    def set_rows(self, rows):
        self.rows_data = [tuple(r) for r in rows]
        self.redraw()

    def rescale(self, s, ppu):
        self._s, self._ppu = s, ppu
        self.configure(border_width=max(2, round(3 * s)))
        for lab, text in zip(self.head_labels, self.headers):
            lab.configure(image=to_ctk_image(render_text([text], "Medium", 24 * ppu, 0.04, C.text_dark), ppu / s))
        self.redraw()

    def redraw(self):
        if not self._s:
            return
        for row in self.body.winfo_children():
            row.destroy()
        for values in self.rows_data:
            DataRow(self.body, values, self._s, self._ppu, self.w).pack(fill="x")
        self.after(60, self._align_header)

    def _align_header(self):
        """Match the header dividers/labels to the body width (the scrollbar narrows the rows)."""
        if not self.winfo_exists() or self.body.winfo_width() < 50:
            return
        dpi = self._ppu / self._s
        left = self.body.winfo_rootx() - self.winfo_rootx()
        rw = self.body.winfo_width()
        for i, div in enumerate(self.head_divs, 1):
            div.place_configure(relx=0, x=round(left + rw * i / self.n))
        for i, lab in enumerate(self.head_labels):
            lab.place_configure(relx=0, x=(left + rw * (i + 0.5) / self.n) / dpi)


class DashboardPage(Page):

    COLUMNS = ["Test Name", "Date", "Marks", "Percentage"]
    SCHEDULE_COLUMNS = ["Subject", "Date", "Time Assigned", "Remarks"]

    def __init__(self, master, app):
        super().__init__(master)
        self.app = app
        self.subject = None
        self.pos, self._target, self._anim = 0.0, 0, None
        self._from, self._started, self._length = 0.0, 0.0, self.TRANSITION
        self._ppu = 1.0

        self.panels = []
        for _ in range(2):
            panel = ctk.CTkFrame(self, fg_color=C.bg, corner_radius=0)
            self.panels.append(panel)
        # Only the top screen has the header, so scrolling down moves it off the page and the table
        # screen reads as the continuation of one long page.
        self.header = HeaderBar(self.panels[0], "STUDY PLANNER", on_back=lambda: app.show_page("home"))
        self.header.place(relx=0, rely=0, relwidth=1, relheight=HEADER_H / BASE_H)
        self._layout()

        # first screen: two charts + the schedule table
        first = self.panels[0]
        self.subject_chart = BarChart(first, "Subject Scores")
        place_rect(self.subject_chart, 40, 160, 580, 400)
        self.test_chart = BarChart(first, "Test Scores")
        place_rect(self.test_chart, 650, 160, 580, 400)
        self.schedule_table = ScrollTable(first, self.SCHEDULE_COLUMNS, (68, 633, 1172, 357))
        place_rect(self.schedule_table, 68, 633, 1172, 357)

        second = self.panels[1]
        self.dropdown = SubjectDropdown(second, lambda: app.subjects, self._on_subject)
        self.dropdown.place(relx=(641 + X_OFF) / BASE_W, rely=255 / BASE_H, anchor="center")
        self.table = ScrollTable(second, self.COLUMNS, (53, 391, 1164, 357))
        place_rect(self.table, 53, 391, 1164, 357)

        root = self.winfo_toplevel()               # events from every child bubble up to the window
        root.bind("<MouseWheel>", self._on_wheel, add="+")
        root.bind("<Down>", lambda _e: self._flip(1), add="+")
        root.bind("<Up>", lambda _e: self._flip(-1), add="+")

    # -- data
    def _on_subject(self, subject):
        self.subject = subject
        self.refresh()

    def rows_for(self, subject):
        """The test table's rows for the selected subject, straight from the SST table: asks the back end
        with `app.emit("test_list", username, subject)` (controller -> test_log.Test_List)."""
        replies = self.app.emit("test_list", self.app.username, subject)
        data = next((r for r in replies if isinstance(r, (tuple, list))), ())      # no back end -> empty table
        rows = []
        for _subject, name, date, usermarks, maxmarks in data:
            if hasattr(date, "strftime"):                      # the database returns a date object
                date = date.strftime("%Y/%m/%d")
            score = f"{usermarks}/{maxmarks}"
            rows.append((name, date or "", score, percentage(score)))
        return rows

    def refresh(self):
        self.table.set_rows(self.rows_for(self.subject) if self.subject else [])
        self.schedule_table.set_rows(self.schedule_rows())
        self._draw_charts()

    # first screen data
    def graph_data(self, event):
        """((name, percentage), ...) for one chart, straight from the SST table: asks the back end with
        `app.emit(event, username)` ("subject_graph" -> test_log.Subject_Graph, "test_graph" ->
        test_log.Test_Graph). The percentages are calculated in the database, highest first."""
        replies = self.app.emit(event, self.app.username)
        return next((r for r in replies if isinstance(r, (tuple, list))), ())      # no back end -> empty chart

    def schedule_rows(self):
        """The schedule table's rows, straight from the database: asks the back end for this user's
        incomplete schedules with `app.emit("schedule_list", username)` (controller ->
        schedule_log.Schedule_List). A schedule disappears once a session with status 1 is stored for it."""
        replies = self.app.emit("schedule_list", self.app.username)
        data = next((r for r in replies if isinstance(r, (tuple, list))), ())      # no back end -> empty table
        rows = []
        for subject, date, time_txt, remarks in data:
            if hasattr(date, "strftime"):                      # the database returns a date object
                date = date.strftime("%Y/%m/%d")
            rows.append((subject, date, time_txt, ("note", remarks or "")))
        return rows

    def _draw_charts(self):
        s, ppu = self.applied_scale, self._ppu
        if not s:
            return
        for chart, event in ((self.subject_chart, "subject_graph"), (self.test_chart, "test_graph")):
            data = self.graph_data(event)
            values = [percent for _name, percent in data]
            ymax = max(100.0, math.ceil(max(values, default=0) / 10) * 10)     # 0-100 %, unless a score is above 100 %
            chart.rescale(ppu)
            chart.set_data([name for name, _percent in data], values, ymax)

    def on_show(self):
        self.refresh()

    # -- scrolling between the two screens
    def _layout(self):
        self.panels[0].place(relx=0, rely=-self.pos, relwidth=1, relheight=1)
        self.panels[1].place(relx=0, rely=1 - self.pos, relwidth=1, relheight=1)

    TRANSITION = 0.6         # seconds a full change from one screen to the other takes

    def go_top(self):
        """Jump straight to the first screen (no animation)."""
        if self._anim is not None:
            self.after_cancel(self._anim)
            self._anim = None
        self.pos, self._target = 0.0, 0
        self._layout()

    def _flip(self, direction):
        """Slide to the other screen (down = +1, up = -1). Only one screen is ever fully open."""
        if self.app.current != "scores":
            return
        target = min(1, max(0, self._target + direction))
        if target == self._target:
            return                                          # already there (or already heading there)
        self._target = target
        self._from, self._started = self.pos, time.perf_counter()
        self._length = max(0.2, self.TRANSITION * abs(target - self._from))    # reversing half way is quicker
        if self._anim is None:
            self._step()

    @staticmethod
    def _ease(u):
        """Ease-in-out: starts gently, speeds up in the middle and settles softly (u and the result are 0..1)."""
        return 4 * u ** 3 if u < 0.5 else 1 - (-2 * u + 2) ** 3 / 2

    def _step(self):
        """One animation frame. The position follows the clock, not the frame count, so it stays
        smooth and takes the same time even if some frames are drawn late."""
        u = min(1.0, (time.perf_counter() - self._started) / self._length)
        self.pos = self._from + (self._target - self._from) * self._ease(u)
        if u >= 1.0:
            self.pos, self._anim = float(self._target), None
        else:
            self._anim = self.after(8, self._step)
        self._layout()

    def _on_wheel(self, event):
        if self.app.current != "scores":
            return
        under = self.winfo_containing(event.x_root, event.y_root)
        for table in (self.table, self.schedule_table):
            if under is not None and str(under).startswith(str(table)) and table.overflows():
                return                              # let the table scroll its own rows
        self._flip(1 if event.delta < 0 else -1)

    def rescale(self, s, ppu):
        super().rescale(s, ppu)
        self.header.rescale(s, ppu)
        self.dropdown.rescale(s, ppu)
        self._ppu = ppu
        self.table.rescale(s, ppu)
        self.schedule_table.rescale(s, ppu)
        self._draw_charts()
