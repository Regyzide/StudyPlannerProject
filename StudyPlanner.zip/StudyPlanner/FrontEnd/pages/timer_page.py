import customtkinter as ctk
import time
from datetime import datetime

from pages import Page, place_rect
from config import BASE_H, BASE_W, C, HEADER_H, X_OFF, render_text, to_ctk_image
from widgets import CircleButton, HeaderBar, SubjectDropdown, TextButton

# --------------------------------------------------------------------------- timer page

def format_time(seconds: float) -> str:
    """M:SS readout from the reference page, or H:MM:SS once an hour has passed."""
    total = int(seconds)
    h, rem = divmod(total, 3600)
    m, s = divmod(rem, 60)
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"

class TimerPage(Page):
    """Study timer: pick a subject, then play / pause / reset.
    The clock counts UP like a stopwatch. reset() stops it, returns the elapsed seconds and
    hands (subject, seconds) to app.log_session so other pages can use it later.
    ImportantNOTE -> YOU HAVE TO HIT RESET IN ORDER TO RETURN THE TIME OR ELSE TIME WON'T BE
    LOGGED AND STORED IN BACK END AND ALL YOUR TASKS WILL BE INCOMPLETE
    """

    def __init__(self, master, app):
        super().__init__(master)
        self.app = app
        self.header = HeaderBar(self, "STUDY PLANNER", on_back=lambda: app.show_page("home"))
        self.header.place(relx=0, rely=0, relwidth=1, relheight=HEADER_H / BASE_H)

        # timer state
        self.running = False
        self.accumulated = 0.0          # seconds banked from earlier play/pause stretches
        self.started_at = 0.0           # perf_counter() when the current stretch began
        self.subject = None
        self._tick_id = None
        self._ppu, self._shown, self._shown_scale = 1.0, None, None

        self.dropdown = SubjectDropdown(self, lambda: app.subjects, self._on_subject)
        self.dropdown.is_locked = lambda: self.elapsed() > 0    # keep the subject until reset
        self.dropdown.place(relx=(640 + X_OFF) / BASE_W, rely=221.5 / BASE_H, anchor="center")

        self.readout = ctk.CTkLabel(self, text="", fg_color="transparent")
        self.readout.place(relx=0.5, rely=485 / BASE_H, anchor="center")

        self.date_label = ctk.CTkLabel(self, text="", fg_color="transparent")
        self.date_label.place(relx=(949 + X_OFF) / BASE_W, rely=221 / BASE_H, anchor="w")

        self.play_btn = CircleButton(self, "play.png", self.start)
        self.pause_btn = CircleButton(self, "pause.png", self.pause)
        self.reset_btn = CircleButton(self, "reset.png", self.reset)
        for btn, cx in ((self.play_btn, 408), (self.pause_btn, 640), (self.reset_btn, 872)):
            btn.place(relx=(cx + X_OFF) / BASE_W, rely=723 / BASE_H, anchor="center")

        self.schedule_btn = TextButton(self, "Today's Schedule", self.open_schedule, size=22)
        place_rect(self.schedule_btn, 467, 912, 351, 66)

    def open_schedule(self):
        """Shortcut to the dashboard's first page (charts + schedule table)."""
        self.app.pages["scores"].go_top()
        self.app.show_page("scores")

    def on_show(self):
        self._draw_date()

    def _draw_date(self):
        s, ppu = self.applied_scale, self._ppu
        if s:
            text = "Date: " + datetime.now().strftime("%Y/%m/%d")
            img = render_text([text], "Medium", 24 * ppu, 0.03, C.text_dark)
            self.date_label.configure(image=to_ctk_image(img, ppu / s))

    # -- timer logic
    def elapsed(self) -> float:
        extra = time.perf_counter() - self.started_at if self.running else 0.0
        return self.accumulated + extra

    def _on_subject(self, subject):
        self.subject = subject

    def start(self):
        if self.running:
            return
        if self.subject is None:                 # need a subject to attribute the time to
            self.dropdown.flash()
            return
        self.running = True
        self.started_at = time.perf_counter()
        self._tick()

    def pause(self):
        if not self.running:
            return
        self.accumulated = self.elapsed()
        self.running = False

    def reset(self) -> float:
        """Stop, zero the clock and return the elapsed seconds."""
        seconds = self.elapsed()
        self.running = False
        self.accumulated = 0.0
        if seconds > 0:
            # announces (username, subject, seconds) to the back end (controller -> timer_log.Set_Detail), which
            # stores the session in the database and returns the status; the dashboard hides completed schedules
            self.app.log_session(self.subject, seconds)
        self._draw_time()
        if seconds > 0:
            return seconds

    def _tick(self):
        self._draw_time()
        if self.running:
            self._tick_id = self.after(100, self._tick)

    def _draw_time(self):
        s, ppu = self.applied_scale or 1.0, self._ppu
        text = format_time(self.elapsed())
        if text != getattr(self, "_shown", None) or self._shown_scale != (s, ppu):
            self._shown, self._shown_scale = text, (s, ppu)
            img = render_text([text], "Medium", 156 * ppu, 0.0, C.text_dark)
            self.readout.configure(image=to_ctk_image(img, ppu / s))

    def rescale(self, s, ppu):
        super().rescale(s, ppu)
        self._ppu = ppu
        self.header.rescale(s, ppu)
        self.dropdown.rescale(s, ppu)
        for btn in (self.play_btn, self.pause_btn, self.reset_btn):
            btn.rescale(s, ppu)
        self.schedule_btn.rescale(s, ppu)
        self._draw_date()
        self._draw_time()
