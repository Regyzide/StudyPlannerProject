import customtkinter as ctk
import tkinter as tk

from pages import Page, place_rect
from config import BASE_H, C, HEADER_H, blend, render_text, to_ctk_image
from widgets import HeaderBar, SquareButton, entry_font

# --------------------------------------------------------------------------- Manage Subjects Page
RED = "#F55C47"                    # remove buttons (measured from manage_subject.png)


class SubjectRow(ctk.CTkFrame):
    """One table row: subject name on the left, small red remove button on the right."""

    def __init__(self, master, subject, on_remove, s, ppu):
        super().__init__(master, fg_color="transparent", corner_radius=0, height=round(102 * s))
        size = 24
        while size > 12:                                          # shrink long names to fit
            text = render_text([subject], "Medium", size * ppu, 0.04, C.text_dark)
            if text.width <= 340 * ppu:
                break
            size -= 1
        label = ctk.CTkLabel(self, text="", fg_color="transparent",
                             image=to_ctk_image(text, ppu / s))
        label.place(relx=73 / 800, rely=0.5, anchor="w")

        remove = SquareButton(self, "minus", on_remove, RED, blend(RED, "#000000", 0.15))
        remove.place(relx=666 / 800, rely=0.5, anchor="center")
        remove.rescale(s, ppu, size=34, glyph=17, thickness=2)

        line = max(1, round(s))        # plain tk frames: reliable 1px lines
        tk.Frame(self, bg=C.text_dark).place(relx=0, rely=1, anchor="sw", relwidth=1, height=line)



class ManageSubjectsPage(Page):
    """Add / remove the logged-in user's subjects. The table lists `app.subjects`, which comes from the
    database (empty list -> empty table), and so do all the subject drop-downs.

    `add_subject()` (the blue + button, or Enter) returns the string typed in the box; it is announced to
    the back end with `app.emit("subject_add", username, subject)` (controller -> subject_log.Subject_Entry)
    and the list is reloaded from the database. Names must be 1-30 characters and not already present.
    `remove_subject(name)` (the red buttons) does the same with "subject_remove" (Subject_Remove).
    """

    TABLE = (227, 543, 800, 378)      # design px; header row is 77 px tall

    def __init__(self, master, app):
        super().__init__(master)
        self.app = app
        self.header = HeaderBar(self, "STUDY PLANNER", on_back=lambda: app.show_page("home"))
        self.header.place(relx=0, rely=0, relwidth=1, relheight=HEADER_H / BASE_H)

        # text box: a white rounded frame with a borderless entry inside (gives the left padding)
        self.box = ctk.CTkFrame(self, fg_color="#FFFFFF", border_color=blend(C.text_dark, "#FFFFFF", 0.4),
                                border_width=1, corner_radius=8)
        place_rect(self.box, 257, 253, 640, 97)
        self.entry = ctk.CTkEntry(self.box, placeholder_text="Add Subject", fg_color="#FFFFFF",
                                  border_width=0, text_color=C.text_dark,
                                  placeholder_text_color=blend(C.text_dark, "#FFFFFF", 0.3))
        self.entry.place(relx=34 / 640, rely=0.5, anchor="w", relwidth=570 / 640, relheight=0.7)
        self.entry.bind("<Return>", lambda _e: self.add_subject())

        self.plus = SquareButton(self, "plus", self.add_subject, C.card, C.card_hover)
        place_rect(self.plus, 925, 253, 98, 97)

        # table
        x, y, w, h = self.TABLE
        self.table = ctk.CTkFrame(self, fg_color="transparent", border_color="#000000",
                                  border_width=3, corner_radius=0)
        place_rect(self.table, *self.TABLE)
        self.head_label = ctk.CTkLabel(self.table, text="", fg_color="transparent")
        self.head_label.place(relx=0.5, rely=38.5 / h, anchor="center")
        self.head_line = tk.Frame(self.table, bg=C.text_dark)
        self.head_line.place(relx=0, rely=77 / h, relwidth=1, height=2)
        self.rows = ctk.CTkScrollableFrame(self.table, fg_color=C.bg, corner_radius=0)
        # inset a few design px so the table's black border stays visible around the rows
        self.rows.place(relx=4 / w, rely=79 / h, relwidth=(w - 8) / w, relheight=(h - 83) / h)

    # -- actions
    def add_subject(self):
        """Return the subject typed in the box (also adds it to the table). None if empty/duplicate."""
        name = self.entry.get().strip()
        if not name or len(name) > 30 or name.lower() in (sub.lower() for sub in self.app.subjects):   # Subjects.SubjectName is varchar(30)
            self._flash_box()
            return None
        self.app.emit("subject_add", self.app.username, name)
        if not self.app.load_subjects():                 # nothing listening (no back end): keep it in memory only
            self.app.subjects.append(name)
        self.entry.delete(0, "end")
        self.entry._activate_placeholder()
        self.refresh()
        return name

    def remove_subject(self, name):
        self.app.emit("subject_remove", self.app.username, name)
        if not self.app.load_subjects() and name in self.app.subjects:
            self.app.subjects.remove(name)
        self.refresh()
        return name

    def _flash_box(self):
        s = self.applied_scale or 1
        self.box.configure(border_color=C.card, border_width=max(2, round(3 * s)))
        self.box.after(400, lambda: self.box.configure(border_color=blend(C.text_dark, "#FFFFFF", 0.4),
                                                       border_width=max(1, round(s))))

    # -- drawing
    def refresh(self):
        s, ppu = self.applied_scale, self._ppu
        if not s:
            return
        for row in self.rows.winfo_children():
            row.destroy()
        for subject in list(self.app.subjects):
            SubjectRow(self.rows, subject, lambda sub=subject: self.remove_subject(sub), s, ppu).pack(fill="x")

    def on_show(self):
        self.refresh()

    def rescale(self, s, ppu):
        super().rescale(s, ppu)
        self._ppu = ppu
        self.header.rescale(s, ppu)
        self.box.configure(corner_radius=round(8 * s), border_width=max(1, round(s)))
        self.entry.configure(font=entry_font(23 * s))
        self.plus.rescale(s, ppu, glyph=34, thickness=3.5, resize=False)
        b = max(2, round(3 * s))
        self.table.configure(border_width=b)
        self.head_label.configure(
            image=to_ctk_image(render_text(["Subject"], "Medium", 24 * ppu, 0.04, C.text_dark), ppu / s))
        self.refresh()
