import customtkinter as ctk
from PIL import Image

from pages import Page, place_rect
from config import ASSETS, BASE_H, BASE_W, C, X_OFF, blend, render_text, to_ctk_image
from widgets import entry_font

# --------------------------------------------------------------------------- shared by the three start pages
# (Login-Signup choice page, Sign-up page, Log-in page: same background, title, welcome text and look)
LOGIN_GREEN = "#9FE6A0"            # green button colour (from the reference pages)
LOGIN_TEAL = "#508C9B"             # LOG-IN button on the choice page
WELCOME = ["Planning has always been a method people use for completing tasks efficiently.",
           "Studying, which falls under the same category, benefits largely from it as well.",
           "In the past, such tools used for planing study schedules were sheets of",
           "paper and notes we left for ourselves. Those trends and tools change now.",
           "Study planner is a platform where modernized trends meet your aspirations.",
           "-"]


class AuthButton(ctk.CTkButton):
    """Wide rounded button with a rendered text label (sized by place_rect)."""

    def __init__(self, master, label, colour, text_colour, command):
        super().__init__(master, text="", command=command, fg_color=colour,
                         hover_color=blend(colour, "#FFFFFF", 0.25), border_width=0,
                         corner_radius=8, width=10, height=10)
        self.label, self.text_colour = label, text_colour

    def rescale(self, s: float, ppu: float):
        self.configure(corner_radius=round(8 * s))
        img = render_text([self.label], "SemiBold", 20 * ppu, 0.12, self.text_colour)
        self.configure(image=to_ctk_image(img, ppu / s))


class AuthPage(Page):
    """Base of the start pages -> full-window background image with the title and welcome text drawn
    into it using pillow, plus helpers to add entries / buttons and to enter the app once the user is accepted.
    The images and fonts are obtained from the assets folder. Design was custom made in photoshop."""

    def __init__(self, master, app):
        super().__init__(master)
        self.app = app
        self._bg_source = Image.open(ASSETS / "background.png").convert("RGB")
        self._bg_after = None
        self.entries, self.buttons = [], []
        self._rects = []             # (widget, design rectangle): used to match corner colours to the image

        # background first, so everything else is stacked above it
        self.background = ctk.CTkLabel(self, text="", fg_color="transparent")
        self.background.place(relx=0, rely=0, relwidth=1, relheight=1)
        self.bind("<Configure>", self._on_resize)

    # -- building blocks
    def add_entry(self, placeholder, rect, show="", on_enter=None):
        entry = ctk.CTkEntry(self, placeholder_text=placeholder, justify="center", fg_color=C.text_light,
                             text_color=C.text_dark, placeholder_text_color=blend(C.text_dark, C.text_light, 0.3),
                             border_width=0, corner_radius=8, width=10, height=10, show=show)
        place_rect(entry, *rect)
        if on_enter:
            entry.bind("<Return>", lambda _e: on_enter())
        self.entries.append(entry)
        self._rects.append((entry, rect))
        return entry

    def add_button(self, label, colour, text_colour, rect, command):
        button = AuthButton(self, label, colour, text_colour, command)
        place_rect(button, *rect)
        self.buttons.append(button)
        self._rects.append((button, rect))
        return button

    # -- behaviour shared by the pages
    def flash(self, entry):
        s = self.applied_scale or 1
        entry.configure(border_color=LOGIN_GREEN, border_width=max(2, round(3 * s)))
        entry.after(400, lambda: entry.configure(border_width=0))

    def clear(self):
        for entry in self.entries:
            if entry._placeholder_text_active:
                continue
            entry.delete(0, "end")
            entry._activate_placeholder()

    def on_show(self):
        self.clear()

    def enter_app(self, user, password):
        """The user was accepted: remember them and open the home page."""
        self.app.credentials = (user, password)
        self.app.username = user
        self.clear()
        self.app.load_subjects()                   # this user's subjects, for every drop-down, obtained from connector, which is inturn obtained from subjects table
        self.app.show_page("home")

    # -- drawing
    def _on_resize(self, _event):
        if self._bg_after:
            self.after_cancel(self._bg_after)
        self._bg_after = self.after(60, self._draw_background)

    def _draw_background(self):
        """Fill the whole window with the background image"""
        self._bg_after = None
        s = self.applied_scale
        root = self.winfo_toplevel()
        w, h = root.winfo_width(), root.winfo_height()
        if not s or w < 10 or h < 10:
            return
        src = self._bg_source
        k = max(w / src.width, h / src.height)
        img = src.resize((round(src.width * k), round(src.height * k)), Image.LANCZOS)
        left, top = (img.width - w) // 2, (img.height - h) // 2
        img = img.crop((left, top, left + w, top + h)).convert("RGBA")

        # tk labels can't be see-through, so the title and welcome text are drawn into the background itself
        ppu = s * self.app._dpi()
        title = render_text(["STUDY PLANNER"], "SemiBold", 66 * ppu, 0.126, C.text_light)
        img.alpha_composite(title, (round(w / 2 - title.width / 2), round(304 / BASE_H * h - title.height / 2)))
        welcome = render_text(WELCOME, "Regular", 20 * ppu, 0.11, C.text_light, line_height=1.45, align="center")
        img.alpha_composite(welcome, (round(w / 2 - welcome.width / 2), round(358 / BASE_H * h)))

        for widget, (x, y, rw, rh) in self._rects:
            px = min(w - 1, max(0, round((x + X_OFF) / BASE_W * w) - 3))
            py = min(h - 1, max(0, round((y + rh / 2) / BASE_H * h)))
            widget.configure(bg_color="#%02X%02X%02X" % img.getpixel((px, py))[:3])

        dpi = self.app._dpi()
        self.background.configure(image=ctk.CTkImage(img.convert("RGB"), size=(w / dpi, h / dpi)))

    def rescale(self, s, ppu):
        super().rescale(s, ppu)
        font = entry_font(20 * s)
        for entry in self.entries:
            entry.configure(font=font, corner_radius=round(8 * s))
        for button in self.buttons:
            button.rescale(s, ppu)
        self._draw_background()
