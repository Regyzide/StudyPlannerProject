import customtkinter as ctk
import re
from datetime import datetime

from pages import Page, place_rect
from config import BASE_H, BASE_W, C, HEADER_H, X_OFF, blend
from widgets import HeaderBar, SubjectDropdown, TextButton, entry_font

# --------------------------------------------------------------------------- add marks page
class AddMarksPage(Page):
    """Add a test result: subject drop-down + three text boxes + Add button.

    `add()` checks the entries, announces them to the back end with
    `app.emit("test", username, subject, name, date, usermarks, maxmarks)` (the controller passes them to
    test_log.Test_Entry, which stores them in the SST table; the dashboard reads them back from there)
    and returns the three strings typed in the boxes as (name, date, score).
    The score must be written as usermarks/maxmarks with whole numbers (e.g. 42/50), the date as a real
    YYYY/MM/DD date and the name at most 30 characters. It returns None (and flashes whatever is
    missing or invalid) otherwise.
    """

    FIELDS = [("name", "Test Number/Name", (213, 453, 310, 97)),
              ("date", "Date: YYYY/MM/DD", (607, 453, 464, 97)),
              ("score", "Your score/Max Score", (213, 620, 858, 97))]

    def __init__(self, master, app):
        super().__init__(master)
        self.app = app
        self.header = HeaderBar(self, "STUDY PLANNER", on_back=lambda: app.show_page("home"))
        self.header.place(relx=0, rely=0, relwidth=1, relheight=HEADER_H / BASE_H)

        self.subject = None
        self.dropdown = SubjectDropdown(self, lambda: app.subjects, lambda sub: setattr(self, "subject", sub))
        self.dropdown.place(relx=(641 + X_OFF) / BASE_W, rely=253 / BASE_H, anchor="center")

        self.entries = {}
        for key, placeholder, rect in self.FIELDS:
            entry = ctk.CTkEntry(self, placeholder_text=placeholder, justify="center", fg_color="#FFFFFF",
                                 border_color=blend(C.text_dark, "#FFFFFF", 0.4), text_color=C.text_dark,
                                 placeholder_text_color=blend(C.text_dark, "#FFFFFF", 0.3),
                                 corner_radius=8, border_width=1, width=10, height=10)
            place_rect(entry, *rect)
            self.entries[key] = entry

        self.add_btn = TextButton(self, "Add", self.add)
        place_rect(self.add_btn, 213, 795, 858, 97)

    def add(self):
        values = tuple(self.entries[k].get().strip() for k in ("name", "date", "score"))
        if self.subject is None:
            self.dropdown.flash()
            return None
        name, date_txt, score = values
        bad = [k for k, v in zip(("name", "date", "score"), values) if not v]          # empty boxes
        if name and len(name) > 30:                                                    # SST.TestName is varchar(30)
            bad.append("name")
        if date_txt:
            try:
                datetime.strptime(date_txt, "%Y/%m/%d")
            except ValueError:
                bad.append("date")
        marks = re.fullmatch(r"\s*(\d+)\s*/\s*(\d+)\s*", score)                         # usermarks/maxmarks, whole numbers
        if score and (not marks or int(marks[2]) == 0):
            bad.append("score")
        if bad:
            for k in set(bad):
                self._flash_entry(self.entries[k])
            return None
        usermarks, maxmarks = int(marks[1]), int(marks[2])
        # announce it: (controller -> test_log.Test_Entry) stores it in the SST table
        self.app.emit("test", self.app.username, self.subject, name, date_txt, usermarks, maxmarks)
        for entry in self.entries.values():
            entry.delete(0, "end")
            entry._activate_placeholder()      # CTkEntry doesn't bring the hint back by itself
        return values

    def _flash_entry(self, entry):
        entry.configure(border_color=C.card, border_width=max(2, round(3 * (self.applied_scale or 1))))
        entry.after(400, lambda: entry.configure(border_color=blend(C.text_dark, "#FFFFFF", 0.4),
                                                 border_width=max(1, round(self.applied_scale or 1))))

    def rescale(self, s, ppu):
        super().rescale(s, ppu)
        self.header.rescale(s, ppu)
        self.dropdown.rescale(s, ppu)
        font = entry_font(21 * s)
        for entry in self.entries.values():
            entry.configure(font=font, corner_radius=round(8 * s), border_width=max(1, round(s)))
        self.add_btn.rescale(s, ppu)
