from pages.auth_page import AuthPage, LOGIN_GREEN
from config import C

# --------------------------------------------------------------------------- login page


class LoginPage(AuthPage):
    """Log in to an existing account (layout from Signup.png): USER-NAME, PASSWORD and SIGN-IN.

    `login()` announces the typed values with `app.emit("login", user, password)`. The controller
    passes them to the back end, which must CHECK them against the database and reply:
        {"ok": True}                        -> accepted: home page opens
        {"ok": False, "message": "..."}     -> refused: the page stays open and the boxes flash
    Unlike signing up, a missing reply counts as refused, so nobody gets in until the back end
    explicitly says yes. Returns (username, password) on success, otherwise None.
    """

    def __init__(self, master, app):
        super().__init__(master, app)
        self.username = self.add_entry("USER-NAME", (354, 593, 573, 63), on_enter=self.login)
        self.password = self.add_entry("PASSWORD", (356, 714, 573, 63), show="•", on_enter=self.login)
        self.login_btn = self.add_button("SIGN-IN", LOGIN_GREEN, C.text_dark, (354, 836, 575, 63), self.login)

    def login(self):
        user, password = self.username.get().strip(), self.password.get()
        missing = [e for e, v in ((self.username, user), (self.password, password)) if not v]
        for entry in missing:
            self.flash(entry)
        if missing:
            return None
        replies = self.app.emit("login", user, password)
        rejected = [r for r in replies if isinstance(r, dict) and r.get("ok") is False]
        approved = [r for r in replies if isinstance(r, dict) and r.get("ok") is True]
        if rejected or not approved:
            self.app.login_message = rejected[0].get("message", "") if rejected else "Login is not available yet"
            self.flash(self.username)
            self.flash(self.password)
            return None
        self.enter_app(user, password)
        return user, password
