from pages.auth_page import AuthPage, LOGIN_GREEN, LOGIN_TEAL
from config import C

# --------------------------------------------------------------------------- login / sign-up choice page


class LoginSignupPage(AuthPage):
    """The first page: choose between logging in to an existing account or signing up for a new one."""

    def __init__(self, master, app):
        super().__init__(master, app)
        self.login_btn = self.add_button("LOG-IN", LOGIN_TEAL, C.text_light, (357, 647, 572, 63),
                                         lambda: app.show_page("login"))
        self.signup_btn = self.add_button("SIGN-UP", LOGIN_GREEN, C.text_dark, (355, 769, 574, 63),
                                          lambda: app.show_page("signup"))
