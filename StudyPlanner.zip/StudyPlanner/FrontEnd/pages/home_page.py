import customtkinter as ctk
import random as r

from pages import MENU, Page, place_rect
from config import BASE_H, C, HEADER_H, render_text, to_ctk_image
from quote_fetching import Quotes
from widgets import CardButton, HeaderBar

# --------------------------------------------------------------------------- home page
Quote_list = Quotes()
QUOTE = [i for i in r.choice(Quote_list.snippets())]# one quote, as a list of lines


class HomePage(Page):
    def __init__(self, master, app):
        super().__init__(master)
        self.header = HeaderBar(self, "STUDY PLANNER")
        self.header.place(relx=0, rely=0, relwidth=1, relheight=HEADER_H / BASE_H)

        self.intro = ctk.CTkLabel(self, text="", fg_color="transparent")
        self.intro.place(relx=0.5, rely=230 / BASE_H, anchor="n")

        self.cards = []
        for key, icon, icon_size, gap, lines, rect, _ in MENU:
            card = CardButton(self, icon, icon_size, gap, lines, command=lambda k=key: app.show_page(k))
            place_rect(card, *rect)
            self.cards.append(card)

    def rescale(self, s, ppu):
        super().rescale(s, ppu)
        self.header.rescale(s, ppu)
        intro = render_text(QUOTE, "SemiBold", 23 * ppu, 0.133, C.text_dark, line_height=29 / 23, align="center")   
        self.intro.configure(image=to_ctk_image(intro, ppu / s))
        for card in self.cards:
            card.rescale(s, ppu)
