import customtkinter as ctk

from config import BASE_H, BASE_W, C, X_OFF

# --------------------------------------------------------------------------- pages
def place_rect(widget, x, y, w, h):
    """Place a widget using a rectangle given in design pixels (stored as fractions)."""
    widget.place(relx=(x + X_OFF) / BASE_W, rely=y / BASE_H, relwidth=w / BASE_W, relheight=h / BASE_H)


class Page(ctk.CTkFrame):
    def __init__(self, master):
        super().__init__(master, fg_color=C.bg, corner_radius=0)
        self.applied_scale = None

    def rescale(self, s: float, ppu: float):
        self.applied_scale = s


MENU = [
    ("scores", "Subject_time_score.png", (81, 67), 16, ["View your subject time", "and scores"],
     (56, 435, 352, 187), "STUDY PLANNER"),
    ("plan", "note_down_plan.png", (57, 67), 22, ["Study Plan", "Scheduler"],
     (464, 435, 351, 187), "STUDY PLANNER"),
    ("timer", "time_study_session.png", (87, 75), 14, ["Time your study sessions"],
     (873, 435, 351, 187), "STUDY PLANNER"),
    ("test", "score_subject_test.png", (60, 78), 20, ["Score your subjects for", "a test"],
     (260, 691, 351, 186), "STUDY PLANNER"),
    ("manage", "manage_subject.png", (61, 58), 27, ["Manage your subjects"],
     (669, 691, 350, 186), "STUDY PLANNER"),
]
