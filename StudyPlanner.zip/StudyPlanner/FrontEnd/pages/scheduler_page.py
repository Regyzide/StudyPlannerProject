import customtkinter as ctk
import re
from datetime import datetime

from pages import Page, place_rect
from config import BASE_H, BASE_W, C, HEADER_H, X_OFF, blend, render_text, to_ctk_image
from widgets import HeaderBar, SubjectDropdown, TextButton, entry_font

BOX_BORDER = blend(C.text_dark, "#FFFFFF", 0.4)
HINT = blend(C.text_dark, "#FFFFFF", 0.3)


class LabelledEntry(ctk.CTkFrame):
    """White rounded box with a small caption on the left and an editable, centred value."""

    def __init__(self, master, caption, placeholder):
        super().__init__(master, fg_color="#FFFFFF", border_color=BOX_BORDER, border_width=1, corner_radius=8)
        self.caption = caption
        self.cap_label = ctk.CTkLabel(self, text="", fg_color="transparent")
        self.cap_label.place(relx=32 / 856, rely=0.5, anchor="w")
        self.entry = ctk.CTkEntry(self, placeholder_text=placeholder, justify="center", fg_color="#FFFFFF",
                                  border_width=0, text_color=C.text_dark, placeholder_text_color=HINT)
        self.entry.place(relx=0.5, rely=0.5, anchor="center", relwidth=0.5, relheight=0.7)

    def get(self) -> str:
        return self.entry.get().strip()

    def set(self, value: str):
        self.entry.delete(0, "end")
        if value:
            self.entry.insert(0, value)
        else:
            self.entry._activate_placeholder()

    def flash(self):
        s = getattr(self, "_s", 1)
        self.configure(border_color=C.card, border_width=max(2, round(3 * s)))
        self.after(400, lambda: self.configure(border_color=BOX_BORDER, border_width=max(1, round(s))))

    def rescale(self, s, ppu):
        self._s = s
        self.configure(corner_radius=round(8 * s), border_width=max(1, round(s)))
        self.entry.configure(font=entry_font(21 * s))
        img = render_text([self.caption], "Medium", 21 * ppu, 0.04, HINT)
        self.cap_label.configure(image=to_ctk_image(img, ppu / s))


# --------------------------------------------------------------------------- Scheduler Page
class SchedulerPage(Page):
    """Study plan scheduler: choose a subject, type the time, the date and (optionally) remarks.
    schedule() checks the entries, announces them to the back end with
    app.emit() function ; (the controller passes them to schedule_log.Schedule_Entry, which stores them in the database; 
    the dashboard reads them back from there) and returns (subject, time, date, remarks). Empty remarks become "No remarks".
    Returns None if the subject is missing or the time / date is empty or invalid.
    """

    NO_REMARKS = "No remarks"

    def __init__(self, master, app):
        super().__init__(master)
        self.app = app
        self.subject = None
        self.header = HeaderBar(self, "STUDY PLANNER", on_back=lambda: app.show_page("home"))
        self.header.place(relx=0, rely=0, relwidth=1, relheight=HEADER_H / BASE_H)

        self.dropdown = SubjectDropdown(self, lambda: app.subjects, self._on_subject)
        self.dropdown.place(relx=(635 + X_OFF) / BASE_W, rely=227 / BASE_H, anchor="center")

        self.time_box = LabelledEntry(self, "Time :", "HH:MM:SS")
        place_rect(self.time_box, 200, 305, 856, 97)
        self.date_box = LabelledEntry(self, "Date :", "YYYY/MM/DD")
        place_rect(self.date_box, 200, 437, 856, 97)

        self.remarks_label = ctk.CTkLabel(self, text="", fg_color="transparent")
        self.remarks_label.place(relx=(200 + X_OFF) / BASE_W, rely=602 / BASE_H, anchor="w")
        self.remarks = ctk.CTkTextbox(self, fg_color="#FFFFFF", border_color=BOX_BORDER, border_width=1,
                                      corner_radius=8, text_color=C.text_dark, wrap="word")
        self.remarks._textbox.tag_configure("center", justify="center")
        place_rect(self.remarks, 334, 571, 722, 275)

        self.schedule_btn = TextButton(self, "Schedule", self.schedule)
        place_rect(self.schedule_btn, 213, 921, 857, 97)

    # -- remarks helpers
    def _get_remarks(self) -> str:
        return self.remarks.get("1.0", "end-1c").strip()

    # -- behaviour
    def _on_subject(self, subject):
        self.subject = subject

    def schedule(self):
        if self.subject is None:
            self.dropdown.flash()
            return None
        time_txt = self.time_box.get()
        date_txt = self.date_box.get()
        remarks = self._get_remarks() or self.NO_REMARKS       # nothing typed -> "No remarks"

        ok = True
        if not re.fullmatch(r"\d{1,3}[.:]\d{2}[.:]\d{2}", time_txt):
            self.time_box.flash()
            ok = False
        try:
            datetime.strptime(date_txt, "%Y/%m/%d")
        except ValueError:
            self.date_box.flash()
            ok = False
        if not ok:
            return None

        entry = (self.subject, time_txt, date_txt, remarks)
        # announce it: (controller -> schedule_log.Schedule_Entry) stores it in the database
        self.app.emit("schedule", self.app.username, self.subject, time_txt, date_txt, remarks)
        self.subject = None                                    # back to a blank form
        self.dropdown.set_selected(None)
        self.time_box.set("")
        self.date_box.set("")
        self.remarks.delete("1.0", "end")
        return entry

    def rescale(self, s, ppu):
        super().rescale(s, ppu)
        self.header.rescale(s, ppu)
        self.dropdown.rescale(s, ppu)
        self.time_box.rescale(s, ppu)
        self.date_box.rescale(s, ppu)
        self.remarks.configure(font=entry_font(21 * s), corner_radius=round(8 * s), border_width=max(1, round(s)))
        self.remarks._textbox.tag_configure("center", justify="center")
        img = render_text(["Remarks:"], "SemiBold", 25 * ppu, 0.06, C.text_dark)
        self.remarks_label.configure(image=to_ctk_image(img, ppu / s))
        self.schedule_btn.rescale(s, ppu)
