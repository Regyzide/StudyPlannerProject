import sys
from pathlib import Path

from pages.auth_page import AuthPage, LOGIN_GREEN
from config import C

# --------------------------------------------------------------------------- signup page
sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "BackEnd"))  #Make data accessible across folders


class SignupPage(AuthPage):
    """Create a new account: username + password boxes and a SIGN-UP button.

    signup() returns (username, password) as typed, announces them to the back end with
    app.emit() method ; (the controller passes them to account_log.py, which stores the
    new pair in the database), then stores them on the app (`app.credentials`, `app.username`) and
    opens the home page. If either box is empty it returns None and flashes it. The back end can
    refuse the sign-up as well in case accounts are already present.
    """

    def __init__(self, master, app):
        super().__init__(master, app)
        self.username = self.add_entry("USERNAME", (353, 591, 572, 62), on_enter=self.signup)
        self.password = self.add_entry("PASSWORD", (355, 712, 572, 62), show="•", on_enter=self.signup)
        self.signup_btn = self.add_button("SIGN-UP", LOGIN_GREEN, C.text_dark, (353, 834, 574, 62), self.signup)

    def signup(self):
        user, password = self.username.get().strip(), self.password.get()
        missing = [e for e, v in ((self.username, user), (self.password, password)) if not v]
        for entry in missing:
            self.flash(entry)
        if missing:
            return None
        # announce it; whatever is listening (see main.py) replies with None or {"ok": ..., "message": ...}
        replies = self.app.emit("signup", user, password)
        rejected = [r for r in replies if isinstance(r, dict) and r.get("ok") is False]
        if rejected:
            self.app.login_message = rejected[0].get("message", "Invalid password or username")     # for a message label later
            self.flash(self.username)
            self.flash(self.password)
            return None
        self.enter_app(user, password)
        return user, password
