import wikiquote as Wquote
from langdetect import detect, lang_detect_exception #This is used to double check language as it wasn't working with filter lang = 'en' in API call

SYMBOLS = ("\'", "\"", "\n", "\t", ".", ",", ":", ";", "-", "~", "!", "?" , chr(32))

LINE_LENGTH = 120
MAX_LINES = 3
FALLBACK = (("Success is the sum of small efforts,",
             "repeated day in and day out."),)


class Quotes:
    """Fetches and formats quotes from wikiquote."""

    def __init__(self, categories=("Perseverance", "Success", "Determination")):
        self.categories = categories
        self._snippets = None

    def snippets(self):
        """Returns all valid quotes."""
        if self._snippets is None:
            self._snippets = []
            for category in self.categories:
                self._snippets.extend(self.quote_gen(category))
            if not self._snippets:
                self._snippets = list(FALLBACK)
        return self._snippets

    @staticmethod
    def clean(quote):
        """Removes unwanted characters from a quote."""
        text = "".join(ch if ch not in "\n\t" else chr(32)for ch in str(quote))
        text = "".join(ch for ch in text if ch.isalnum() or ch in SYMBOLS or ch in "\n\t" or ch == chr(32))
        text = "\"" + text + "\""
        return " ".join(text.split())

    @staticmethod
    def text_split(statement, frequency=LINE_LENGTH):
        """Splits text into lines of a maximum length."""
        lines, current = [], ""
        for word in statement.split():
            if current and len(current) + 1 + len(word) > frequency:
                lines.append(current)
                current = word
            else:
                current = f"{current} {word}".strip()
        if current:
            lines.append(current)
        return tuple(lines)

    def quote_gen(self, category):
        """Returns the valid quotes of a category."""
        try:
            quotes = Wquote.quotes(category, max_quotes=200, lang = 'en')
        except Exception:
            return []
        valid = []
        for quote in quotes:
            try:
                lines = self.text_split(self.clean(quote))
                if lines and len(lines) <= MAX_LINES and all(len(line) <= LINE_LENGTH for line in lines) and detect(quote) == 'en': 
                    valid.append(lines)
                    valid[0]
            except lang_detect_exception: #Makes sure language is english
                continue
        return valid

