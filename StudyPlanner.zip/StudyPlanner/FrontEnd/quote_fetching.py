import wikiquote as Wquote

SYMBOLS = ("\'", "\"", "\n", "\t", ".", ",", ":", ";", "-", "~", "!", "?" , chr(32))

# --------------------------------------------------------------------------- quote fetching
LINE_LENGTH = 120                    # characters per displayed line
MAX_LINES = 3                        # a valid quote fits in three lines -> 360 characters at most
FALLBACK = (("Success is the sum of small efforts,",
             "repeated day in and day out."),)      # used only if wikiquote can't be reached


class Quotes:
    """Fetches quotes from wikiquote and turns them into lines ready to be displayed.

    `snippets()` returns a list of valid quotes. Every quote is a tuple of lines (strings), at most
    MAX_LINES lines of LINE_LENGTH characters each, so `render_text(list(quote), ...)` can draw it.
    """

    def __init__(self, categories=("Perseverance", "Success", "Determination")):
        self.categories = categories
        self._snippets = None

    def snippets(self):
        """All valid quotes of every category (fetched once, then cached)."""
        if self._snippets is None:
            self._snippets = []
            for category in self.categories:
                self._snippets.extend(self.quote_gen(category))
            if not self._snippets:
                self._snippets = list(FALLBACK)
        return self._snippets

    @staticmethod
    def clean(quote):
        """Keep letters, digits and the characters listed in SYMBOLS; tidy whitespace."""
        text = "".join(ch if ch not in "\n\t" else chr(32)for ch in str(quote))
        text = "".join(ch for ch in text if ch.isalnum() or ch in SYMBOLS or ch in "\n\t" or ch == chr(32))
        text = "\"" + text + "\""
        return " ".join(text.split())

    @staticmethod
    def text_split(statement, frequency=LINE_LENGTH):
        """Word-wrap `statement` into lines of at most `frequency` characters."""
        lines, current = [], ""
        for word in statement.split():
            if current and len(current) + 1 + len(word) > frequency:
                lines.append(current)
                current = word
            else:
                current = f"{current} {word}".strip()
        if current:
            lines.append(current)
        return tuple(lines)

    def quote_gen(self, category):
        """Valid quotes (tuples of lines) from one wikiquote category."""
        try:
            quotes = Wquote.quotes(category, max_quotes=200, lang = 'en')      #Filters to only english quotes
        except Exception:                          # no internet, page missing, ...
            return []
        valid = []
        for quote in quotes:
            lines = self.text_split(self.clean(quote))
            if lines and len(lines) <= MAX_LINES and all(len(line) <= LINE_LENGTH for line in lines):
                valid.append(lines)
                valid[0]
        return valid
