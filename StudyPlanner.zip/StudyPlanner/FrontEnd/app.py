"""
Every widget is positioned with relative coordinates (place relx/rely/relwidth/relheight),
so the layout stretches with the window.

This file runs without the backend, just to show all the details.
"""
import traceback

import customtkinter as ctk
from datetime import datetime

from pages.add_marks_page import AddMarksPage
from pages.dashboard_page import DashboardPage
from pages.home_page import HomePage
from pages.login_page import LoginPage
from pages.login_signup_page import LoginSignupPage
from pages.manage_subjects_page import ManageSubjectsPage
from pages.signup_page import SignupPage
from pages import MENU
from config import ASSETS, BASE_H, BASE_W, C, FONT_DIR
from pages.scheduler_page import SchedulerPage
from pages.timer_page import TimerPage

# --------------------------------------------------------------------------- app
class App(ctk.CTk):
    def __init__(self):
        super().__init__(fg_color=C.bg)
        self.title("Study Planner")
        self._set_initial_geometry()
        self.minsize(760, 640)
        try:                                           # Assets/ sits next to FrontEnd/, wherever the project folder is
            self.iconbitmap(str(ASSETS / "studyPlannerLogo.ico"))
        except Exception:                              # .ico window icons only work on Windows; skip elsewhere
            pass

        container = ctk.CTkFrame(self, fg_color=C.bg, corner_radius=0)
        container.pack(fill="both", expand=True)
        container.grid_rowconfigure(0, weight=1)
        container.grid_columnconfigure(0, weight=1)

        # The logged-in user's subjects: loaded from the database after login / sign-up (see load_subjects).
        # Every subject drop-down reads this list.
        self.subjects = []
        self.session_log = []         # [(subject, seconds, 'YYYY/MM/DD')] filled in whenever the timer is reset

        self.credentials = None          # (username, password) once the user has logged in
        self.username = None
        self._listeners = {}             # event name -> functions registered with on() (see main.py)

        # the three start pages (reachable before logging in), then the home page
        self.pages = {"welcome": LoginSignupPage(container, self), "login": LoginPage(container, self),
                      "signup": SignupPage(container, self), "home": HomePage(container, self)}
        for key, *_, title in MENU:
            if key == "timer":
                self.pages[key] = TimerPage(container, self)
            elif key == "plan":
                self.pages[key] = SchedulerPage(container, self)
            elif key == "scores":
                self.pages[key] = DashboardPage(container, self)
            elif key == "test":
                self.pages[key] = AddMarksPage(container, self)
            elif key == "manage":
                self.pages[key] = ManageSubjectsPage(container, self)
            else:
                self.pages[key] = SubPage(container, self, title)
        for page in self.pages.values():
            page.grid(row=0, column=0, sticky="nsew")

        self.scale = 0.0
        self._after_id = None
        self.current = "welcome"
        self.bind("<Configure>", self._on_configure)
        self.bind("<Escape>", self._on_escape)
        self.show_page("welcome")
        self.after(30, self._apply_scale)

    # -- events: how the front end hands data to whoever is listening (the controller), no imports needed
    def on(self, event: str, function):
        """Register `function` to be called whenever the front end emits `event`."""
        self._listeners.setdefault(event, []).append(function)

    def emit(self, event: str, *data):
        """Announce `event` with `data`. Returns a list with what each listener returned (the replies).
        """
        replies = []
        for function in self._listeners.get(event, []):
            try:
                replies.append(function(*data))
            except Exception:
                traceback.print_exc()
                replies.append(None)
        return replies

    def load_subjects(self):
        """Reload this user's subjects from the database (through the back end).
        """
        for reply in self.emit("subjects", self.username):
            if isinstance(reply, list):
                self.subjects[:] = reply
                return True
        return False

    def log_session(self, subject, seconds):
        """Called when the timer is reset. Keeps the session in memory and announces it to the back end,
        which stores it in the database and replies with the status (1 = that day's schedule for the subject
        is complete). Returns the status; the dashboard asks the database for the schedules that are still
        incomplete, so a completed one is gone the next time the dashboard is shown. The logic for the filteration
        is taken care of in the back end query call directly."""
        today = datetime.now().strftime("%Y/%m/%d")
        self.session_log.append((subject, seconds, today))
        replies = self.emit("timer_reset", self.username, subject, seconds)
        return next((r for r in replies if r in (0, 1)), 0)        # no back end / database error -> 0

    # -- navigation (this is what the buttons call)
    START_PAGES = ("welcome", "login", "signup")

    def _on_escape(self, _event):
        """Clicking escape goes one page back from the current page"""
        if self.credentials is not None:
            self.show_page("home")
        elif self.current in ("login", "signup"):
            self.show_page("welcome")

    def show_page(self, key: str):
        if key not in self.START_PAGES and self.credentials is None:    # nothing else is reachable before logging in
            key = "welcome"
        self.current = key
        page = self.pages[key]
        if page.applied_scale != self.scale and self.scale:
            page.rescale(self.scale, self.scale * self._dpi())
        page.tkraise()
        if hasattr(page, "on_show"):
            page.on_show()

    # -- sizing
    def _dpi(self) -> float:
        try:
            return ctk.ScalingTracker.get_window_scaling(self)
        except AttributeError:                       # older CustomTkinter versions
            return self._get_window_scaling()

    def _set_initial_geometry(self):
        dpi = self._dpi()
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        k = min(1.0, (sw / dpi - 40) / BASE_W, (sh / dpi - 140) / BASE_H)
        w, h = round(BASE_W * k), round(BASE_H * k)
        x, y = int((sw - w * dpi) / 2), max(0, int((sh - h * dpi) / 2) - 30)
        self.geometry(f"{w}x{h}+{x}+{y}")

    def _on_configure(self, event):
        if event.widget is self:                      # ignore events bubbling up from children
            if self._after_id:
                self.after_cancel(self._after_id)
            self._after_id = self.after(40, self._apply_scale)   # debounce while dragging

    def _apply_scale(self):
        self._after_id = None
        dpi = self._dpi()
        s = min(self.winfo_width() / dpi / BASE_W, self.winfo_height() / dpi / BASE_H)
        if s <= 0 or abs(s - self.scale) < 0.004:
            return
        self.scale = s
        self.pages[self.current].rescale(s, s * dpi)   # other pages update when first shown


if __name__ == "__main__":
    if not (FONT_DIR / "Barlow-Medium.ttf").exists():
        raise SystemExit(f"Barlow fonts not found in {FONT_DIR}\n"
                         "Keep the Assets folder next to the FrontEnd folder.")
    ctk.set_appearance_mode("dark")
    App().mainloop()
