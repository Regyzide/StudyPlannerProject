import customtkinter as ctk
import tkinter as tk
from PIL import Image, ImageDraw

from config import C, CONTENT_DROP, FONT_DIR, HEADER_H, load_glyph, load_icon, render_text, symbol_image, to_ctk_image

# --------------------------------------------------------------------------- widgets
class CardButton(ctk.CTkButton):
    """One big rounded menu button: [icon]  [text lines], centred as a group."""

    def __init__(self, master, icon_file, icon_size, gap, lines, command):
        super().__init__(master, text="", command=command, width=10, height=10,
                         fg_color=C.card, hover_color=C.card_hover,
                         border_color=C.card_border, border_width=1, corner_radius=10)
        self.icon_file, self.icon_size, self.gap, self.lines = icon_file, icon_size, gap, lines

    def rescale(self, s: float, ppu: float):
        """s = design-px -> logical-px factor, ppu = design-px -> physical-px factor."""
        # 1) shape: corner radius and border follow the scale
        self.configure(corner_radius=round(10 * s), border_width=max(1, round(s)))

        # 2) content: icon + text composed into one image at the new size
        icon = load_icon(self.icon_file).resize(
            (round(self.icon_size[0] * ppu), round(self.icon_size[1] * ppu)), Image.LANCZOS)
        text = render_text(self.lines, "Medium", 18 * ppu, 0.05, C.text_light, line_height=22 / 18)
        gap = round(self.gap * ppu)
        drop = round(CONTENT_DROP * ppu)

        content_h = max(icon.height, text.height)
        canvas = Image.new("RGBA", (icon.width + gap + text.width, content_h + 2 * drop), (0, 0, 0, 0))
        canvas.paste(icon, (0, 2 * drop + (content_h - icon.height) // 2), icon)
        canvas.paste(text, (icon.width + gap, 2 * drop + (content_h - text.height) // 2), text)
        self.configure(image=to_ctk_image(canvas, ppu / s))


class BackButton(ctk.CTkButton):
    """Small outlined 'BACK' button used in the header of the sub pages."""

    def __init__(self, master, command):
        super().__init__(master, text="", command=command, fg_color="#F3F4F4",
                         hover_color=C.header_hover, border_color=C.text_light, border_width=2)

    def rescale(self, s: float, ppu: float):
        self.configure(width=round(104 * s), height=round(40 * s),
                       corner_radius=round(8 * s), border_width=max(1, round(2 * s)))
        img = render_text(["BACK"], "SemiBold", 16 * ppu, 0.12, C.text_dark)
        self.configure(image=to_ctk_image(img, ppu / s))


class HeaderBar(ctk.CTkFrame):
    """Teal title bar. Sub pages also get a BACK button on the right."""

    def __init__(self, master, title, on_back=None):
        super().__init__(master, fg_color=C.header, corner_radius=0)
        self.title_text = title
        self.title_label = ctk.CTkLabel(self, text="", fg_color="transparent")
        self.title_label.place(x=24, rely=41.5 / HEADER_H, anchor="w")
        self.back = None
        if on_back:
            self.back = BackButton(self, on_back)
            self.back.place(relx=1, x=-24, rely=0.5, anchor="e")

    def rescale(self, s: float, ppu: float):
        img = render_text([self.title_text], "SemiBold", 31 * ppu, 0.126, C.text_light)
        self.title_label.configure(image=to_ctk_image(img, ppu / s))
        self.title_label.place_configure(x=24 * s)
        if self.back:
            self.back.rescale(s, ppu)
            self.back.place_configure(x=-24 * s)

class SubjectDropdown(ctk.CTkButton):
    """'Subject v' button. Clicking opens a menu with every available subject."""

    W, H = 310, 70

    def __init__(self, master, get_subjects, on_select):
        super().__init__(master, text="", command=self._open, fg_color=C.card,
                         hover_color=C.card_hover, border_color=C.card_border, border_width=1)
        self.get_subjects, self.on_select = get_subjects, on_select
        self.selected = None
        self.is_locked = lambda: False
        self._scale = (1.0, 1.0)
        self.menu = tk.Menu(self, tearoff=0, bg=C.card, fg=C.text_light, activebackground=C.header,
                            activeforeground=C.text_light, bd=0, relief="flat",
                            font=("Segoe UI", 13))

    def set_selected(self, subject):
        self.selected = subject
        self.rescale(*self._scale)

    def _open(self):
        if self.is_locked():
            self.flash()
            return
        self.menu.delete(0, "end")
        for subject in self.get_subjects():
            self.menu.add_command(label=f"  {subject}  ", command=lambda sub=subject: self._pick(sub))
        self.menu.tk_popup(self.winfo_rootx(), self.winfo_rooty() + self.winfo_height())

    def _pick(self, subject):
        self.set_selected(subject)
        self.on_select(subject)

    def flash(self):
        """Briefly highlight the button (used when a subject is needed)."""
        self.configure(border_color=C.text_light, border_width=max(2, round(3 * self._scale[0])))
        self.after(350, lambda: self.configure(border_color=C.card_border,
                                               border_width=max(1, round(self._scale[0]))))

    def rescale(self, s: float, ppu: float):
        self._scale = (s, ppu)
        self.configure(width=round(self.W * s), height=round(self.H * s),
                       corner_radius=round(8 * s), border_width=max(1, round(s)))
        self.place_configure(width=round(self.W * s), height=round(self.H * s))
        label =self.selected or "Subject"
        size, text = 26, None
        while size > 12:                                          # shrink long names to fit
            text = render_text([label], "Medium", size * ppu, 0.05, C.text_light)
            if text.width <= 150 * ppu:
                break
            size -= 1

        # sample layout inside the 310px button: text centred at x~148, arrow centred at x~267
        arrow_w, arrow_h = round(23 * ppu), round(13 * ppu)
        canvas = Image.new("RGBA", (round(self.W * ppu), round(self.H * ppu)), (0, 0, 0, 0))
        canvas.paste(text, (round(148 * ppu - text.width / 2), (canvas.height - text.height) // 2 + round(2 * ppu)), text)
        tri = Image.new("RGBA", (arrow_w * 4, arrow_h * 4), (0, 0, 0, 0))
        ImageDraw.Draw(tri).polygon([(0, 0), (tri.width, 0), (tri.width / 2, tri.height)], fill=C.text_light)
        tri = tri.resize((arrow_w, arrow_h), Image.LANCZOS)
        canvas.paste(tri, (round(267 * ppu - arrow_w / 2), (canvas.height - arrow_h) // 2 + round(2 * ppu)), tri)
        self.configure(image=to_ctk_image(canvas, ppu / s))

class CircleButton(ctk.CTkButton):
    """Round icon button (play / pause / reset)."""

    def __init__(self, master, glyph_file, command):
        """The whole circle (disc + glyph) is one image: a CTkButton's own corner radius would
        eat all the room the image needs. Hover is done by swapping to a lighter disc."""
        super().__init__(master, text="", command=command, fg_color=C.bg, hover_color=C.bg,
                         border_width=0, corner_radius=0)
        self.glyph_file = glyph_file
        self._images = None
        self.bind("<Enter>", lambda _e: self._show(1), add="+")
        self.bind("<Leave>", lambda _e: self._show(0), add="+")

    def _show(self, i):
        if self._images:
            self.configure(image=self._images[i])

    def rescale(self, s: float, ppu: float):
        d = 90                                                    # circle diameter in the sample
        px = round(d * ppu)
        glyph = load_glyph(self.glyph_file, px)
        images = []
        for colour in (C.card, C.card_hover):
            big = Image.new("RGBA", (px * 4, px * 4), (0, 0, 0, 0))
            ImageDraw.Draw(big).ellipse((0, 0, px * 4 - 1, px * 4 - 1), fill=colour)
            disc = big.resize((px, px), Image.LANCZOS)
            disc.alpha_composite(glyph)
            images.append(to_ctk_image(disc, ppu / s))
        self._images = images
        box = round(d * s) + 24                                   # slack so the grid padding can't clip it
        self.configure(width=box, height=box, image=images[0])
        self.place_configure(width=box, height=box)

class TextButton(ctk.CTkButton):
    """Wide rounded button with a single rendered text label (sized by place_rect)."""

    def __init__(self, master, label, command, size=30):
        super().__init__(master, text="", command=command, fg_color=C.card, hover_color=C.card_hover,
                         border_color=C.card_border, border_width=1, corner_radius=8, width=10, height=10)
        self.label, self.size = label, size

    def rescale(self, s: float, ppu: float):
        self.configure(corner_radius=round(8 * s), border_width=max(1, round(s)))
        img = render_text([self.label], "SemiBold", self.size * ppu, 0.08, C.text_light)
        self.configure(image=to_ctk_image(img, ppu / s))

class SquareButton(ctk.CTkButton):
    """Rounded square button holding a '+' or '-' symbol."""

    def __init__(self, master, kind, command, colour, hover):
        super().__init__(master, text="", command=command, fg_color=colour, hover_color=hover,
                         border_width=0, corner_radius=8, width=10, height=10)
        self.kind = kind

    def rescale(self, s: float, ppu: float, size=48, glyph=24, thickness=2.5, resize=True):
        self.configure(corner_radius=round(8 * s))
        if resize:
            self.configure(width=round(size * s), height=round(size * s))
            self.place_configure(width=round(size * s), height=round(size * s))
        self.configure(image=to_ctk_image(symbol_image(self.kind, glyph, thickness, ppu), ppu / s))


_ENTRY_FONT = {}


def entry_font(size_px: float) -> ctk.CTkFont:
    """Barlow Medium for real Tk entries (registered for this process only, no install needed)."""
    if "family" not in _ENTRY_FONT:
        family = "Segoe UI"
        try:
            if ctk.FontManager.load_font(str(FONT_DIR / "Barlow-Medium.ttf")):
                family = "Barlow Medium"
        except Exception:
            pass
        _ENTRY_FONT["family"] = family
    return ctk.CTkFont(family=_ENTRY_FONT["family"], size=max(8, round(size_px)))
