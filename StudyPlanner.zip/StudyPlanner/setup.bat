@echo off
setlocal
cd /d "%~dp0"
set "CODE=0"
set "PY="

where python >nul 2>nul && set "PY=python"
if not defined PY where py >nul 2>nul && set "PY=py -3"
if not defined PY (
    echo Python was not found. Install Python 3 from https://www.python.org/downloads/ and tick Add Python to PATH, then run this file again.
    goto :fail
)

if not exist "requirements.txt" (
    echo requirements.txt is missing from this folder.
    goto :fail
)

if not exist "Entries\mysqlData.txt" (
    echo Entries\mysqlData.txt was not found. Create it with your MySQL login details first, then run this file again.
    goto :fail
)

echo Installing the required libraries...
%PY% -m pip install -r requirements.txt
if errorlevel 1 (
    echo The libraries could not be installed. Check your internet connection and try again.
    goto :fail
)

echo.
echo Creating the database tables...
%PY% ddl.py
if errorlevel 1 (
    echo The tables could not be created. If they already exist, setup was already done. Otherwise check that MySQL is running and that Entries\mysqlData.txt is correct.
    goto :fail
)

echo.
echo Setup finished. Start the app with:  %PY% main.py
goto :end

:fail
echo.
echo Setup did not finish.
set "CODE=1"

:end
if /i not "%~1"=="nopause" pause
exit /b %CODE%