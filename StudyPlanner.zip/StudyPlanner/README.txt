Python version 3.9 or higher must be installed and added to path. 
MySQL version 8.0 or higher must be installed and added to path.

To add to path, edit system environment variables and add the directories to the folders of Python and MySQL.

This app is just a prototype/concept for a school project.

---------------------------------------------------------------

Database must be created and the name of the database must be entered in mysqlData.txt under Entries folder as instructed (Refer file for instructions)
Username and password must be entered in mysqlData.txt under Entries folder as instructed (Refer file for instructions)

After finishing the above steps, run SETUP.bat once to install all the required libraries and create all necessary tables.

ddl.py is a file used to create all the tables the app will be using in order to store data. You don't need to run this after running SETUP.bat

Run main.py to launch the app

---------------------------------------------------------------