"""
Study Planner - home page (CustomTkinter)

Setup
-----
1. Put this file INSIDE the StudyPlanner folder, next to the PNG icons and BarlowFont/.
2. pip install customtkinter pillow
3. python study_planner.py

How the scaling works
---------------------
* Every widget is positioned with *relative* coordinates (place relx/rely/relwidth/relheight),
  so the layout stretches with the window.
* On each resize the app works out one scale factor (window size / 1277x1079 design size)
  and pushes it into every widget: button corner radius + border width, icon size, font size.
* Text is drawn with Pillow from the bundled Barlow .ttf files. The sample uses wide
  letter-spacing, which Tk labels can't do, and this way no font install is needed.
  Images are re-rendered at the new size, so text stays sharp at any window size.
* CustomTkinter's own DPI scaling is respected (see `ppu` = pixels per design pixel).
"""
from pathlib import Path
from types import SimpleNamespace

import customtkinter as ctk
from PIL import Image, ImageDraw, ImageFont

# --------------------------------------------------------------------------- paths
ASSETS = Path(__file__).resolve().parent
FONT_DIR = ASSETS / "BarlowFont"

# --------------------------------------------------------------------------- design size
BASE_W, BASE_H = 1280, 1080          # size of Sample.png (design pixels)
HEADER_H = 80
CONTENT_DROP = 3                     # the sample places each icon+text group ~3px below centre


# --------------------------------------------------------------------------- colours
def blend(c1: str, c2: str, t: float) -> str:
    """Mix hex colour c1 towards c2 by t (0..1). Used for hover / border shades."""
    a = [int(c1[i:i + 2], 16) for i in (1, 3, 5)]
    b = [int(c2[i:i + 2], 16) for i in (1, 3, 5)]
    return "#" + "".join(f"{round(x + (y - x) * t):02X}" for x, y in zip(a, b))


# Colours measured from Sample.png (these are also the colours baked into the icon PNGs).
SAMPLE_COLOURS = dict(header="#5F9598", bg="#F3F4F4", card="#1D546D",
                      text_dark="#061E29", text_light="#F3F4F4")
# Colours from Color_pallet.png (navy / slate / mint / off-white), mapped onto the same roles.
PALLET_COLOURS = dict(header="#7F8CAA", bg="#EAEFEF", card="#333446",
                      text_dark="#333446", text_light="#EAEFEF")

USE_PALLET_PNG_COLOURS = False       # <- flip to True to use the colours of Color_pallet.png

C = SimpleNamespace(**(PALLET_COLOURS if USE_PALLET_PNG_COLOURS else SAMPLE_COLOURS))
C.card_hover = blend(C.card, C.text_light, 0.12)
C.card_border = blend(C.card, "#000000", 0.35)
C.header_hover = blend(C.header, C.text_light, 0.25)


# --------------------------------------------------------------------------- image helpers
_ICON_CACHE: dict = {}


def load_icon(filename: str) -> Image.Image:
    """Load an icon, make its background transparent, recolour it and crop to the drawing.

    The supplied icons are opaque (card colour behind light lines), except manage_subject.png
    which already has transparency. Deriving the alpha from brightness keeps the anti-aliased
    edges clean and lets the icon work on any background / palette.
    """
    if filename in _ICON_CACHE:
        return _ICON_CACHE[filename]

    img = Image.open(ASSETS / filename).convert("RGBA")
    if filename == "manage_subject.png":
        alpha = img.getchannel("A")
    else:
        lum = img.convert("L")
        lo = Image.new("RGB", (1, 1), (0x1D, 0x54, 0x6D)).convert("L").getpixel((0, 0))   # bg
        hi = Image.new("RGB", (1, 1), (0xF3, 0xF4, 0xF4)).convert("L").getpixel((0, 0))   # lines
        alpha = lum.point(lambda v: max(0, min(255, round((v - lo) / (hi - lo) * 255))))

    box = alpha.point(lambda v: 255 if v > 20 else 0).getbbox()      # tight crop
    icon = Image.new("RGBA", img.size, C.text_light)
    icon.putalpha(alpha)
    _ICON_CACHE[filename] = icon.crop(box)
    return _ICON_CACHE[filename]


def render_text(lines, weight, size, tracking, color, line_height=1.3, align="left") -> Image.Image:
    """Draw text with real letter-spacing and return a tightly cropped RGBA image.

    size      font size in pixels
    tracking  extra space after each letter, in em (0.1 = 10% of the font size)
    """
    font = ImageFont.truetype(str(FONT_DIR / f"Barlow-{weight}.ttf"), max(1, round(size)))
    track = tracking * size
    widths = [font.getlength(t) + track * (len(t) - 1) for t in lines]
    pad = round(size)
    pitch = line_height * size
    w = round(max(widths)) + 2 * pad
    h = round(pitch * (len(lines) - 1) + size * 1.6) + 2 * pad

    mask = Image.new("L", (w, h), 0)
    draw = ImageDraw.Draw(mask)
    for i, text in enumerate(lines):
        x0 = pad + ((max(widths) - widths[i]) / 2 if align == "center" else 0)
        baseline = pad + size + i * pitch
        for j, ch in enumerate(text):
            draw.text((x0 + font.getlength(text[:j]) + j * track, baseline), ch,
                      font=font, fill=255, anchor="ls")

    mask = mask.crop(mask.getbbox())
    out = Image.new("RGBA", mask.size, color)
    out.putalpha(mask)
    return out


def to_ctk_image(img: Image.Image, dpi: float) -> ctk.CTkImage:
    """Wrap a PIL image so it is shown 1:1 on screen (CTk multiplies the size by dpi)."""
    return ctk.CTkImage(img, size=(img.width / dpi, img.height / dpi))


# --------------------------------------------------------------------------- widgets
class CardButton(ctk.CTkButton):
    """One big rounded menu button: [icon]  [text lines], centred as a group."""

    def __init__(self, master, icon_file, icon_size, gap, lines, command):
        super().__init__(master, text="", command=command, width=10, height=10,
                         fg_color=C.card, hover_color=C.card_hover,
                         border_color=C.card_border, border_width=1, corner_radius=10)
        self.icon_file, self.icon_size, self.gap, self.lines = icon_file, icon_size, gap, lines

    def rescale(self, s: float, ppu: float):
        """s = design-px -> logical-px factor, ppu = design-px -> physical-px factor."""
        # 1) shape: corner radius and border follow the scale
        self.configure(corner_radius=round(10 * s), border_width=max(1, round(s)))

        # 2) content: icon + text composed into one image at the new size
        icon = load_icon(self.icon_file).resize(
            (round(self.icon_size[0] * ppu), round(self.icon_size[1] * ppu)), Image.LANCZOS)
        text = render_text(self.lines, "Medium", 18 * ppu, 0.05, C.text_light, line_height=22 / 18)
        gap = round(self.gap * ppu)
        drop = round(CONTENT_DROP * ppu)

        content_h = max(icon.height, text.height)
        canvas = Image.new("RGBA", (icon.width + gap + text.width, content_h + 2 * drop), (0, 0, 0, 0))
        canvas.paste(icon, (0, 2 * drop + (content_h - icon.height) // 2), icon)
        canvas.paste(text, (icon.width + gap, 2 * drop + (content_h - text.height) // 2), text)
        self.configure(image=to_ctk_image(canvas, ppu / s))


class BackButton(ctk.CTkButton):
    """Small outlined 'BACK' button used in the header of the sub pages."""

    def __init__(self, master, command):
        super().__init__(master, text="", command=command, fg_color="#1D546D",
                         hover_color=C.header_hover, border_color=C.text_light, border_width=2)

    def rescale(self, s: float, ppu: float):
        self.configure(width=round(104 * s), height=round(40 * s),
                       corner_radius=round(8 * s), border_width=max(1, round(2 * s)))
        img = render_text(["BACK"], "SemiBold", 16 * ppu, 0.12, C.text_light)
        self.configure(image=to_ctk_image(img, ppu / s))


class HeaderBar(ctk.CTkFrame):
    """Teal title bar. Sub pages also get a BACK button on the right."""

    def __init__(self, master, title, on_back=None):
        super().__init__(master, fg_color=C.header, corner_radius=0)
        self.title_text = title
        self.title_label = ctk.CTkLabel(self, text="", fg_color="transparent")
        self.title_label.place(x=24, rely=41.5 / HEADER_H, anchor="w")
        self.back = None
        if on_back:
            self.back = BackButton(self, on_back)
            self.back.place(relx=1, x=-24, rely=0.5, anchor="e")

    def rescale(self, s: float, ppu: float):
        img = render_text([self.title_text], "SemiBold", 31 * ppu, 0.126, C.text_light)
        self.title_label.configure(image=to_ctk_image(img, ppu / s))
        self.title_label.place_configure(x=24 * s)
        if self.back:
            self.back.rescale(s, ppu)
            self.back.place_configure(x=-24 * s)


# --------------------------------------------------------------------------- pages
def place_rect(widget, x, y, w, h):
    """Place a widget using a rectangle given in design pixels (stored as fractions)."""
    widget.place(relx=x / BASE_W, rely=y / BASE_H, relwidth=w / BASE_W, relheight=h / BASE_H)


class Page(ctk.CTkFrame):
    def __init__(self, master):
        super().__init__(master, fg_color=C.bg, corner_radius=0)
        self.applied_scale = None

    def rescale(self, s: float, ppu: float):
        self.applied_scale = s


# key, icon file, icon size (design px), icon->text gap, text lines, card rect (x, y, w, h), sub-page title
MENU = [
    ("scores", "Subject_time_score.png", (81, 67), 16, ["View your subject time", "and scores"],
     (56, 435, 352, 187), "SUBJECT TIME & SCORES"),
    ("plan", "note_down_plan.png", (57, 67), 22, ["Note down and plan", "whatever you have to do"],
     (464, 435, 351, 187), "NOTES & PLANS"),
    ("timer", "time_study_session.png", (87, 75), 14, ["Time your study sessions"],
     (873, 435, 351, 187), "STUDY TIMER"),
    ("test", "score_subject_test.png", (60, 78), 20, ["Score your subjects for", "a test"],
     (260, 691, 351, 186), "SCORE A TEST"),
    ("manage", "manage_subject.png", (61, 58), 27, ["Manage your subjects"],
     (669, 691, 350, 186), "MANAGE SUBJECTS"),
]

LOREM = ["Nunc purus orci, vestibulum sit amet risus ac, euismod congue lorem. Etiam",
         "pretium est eget nisl congue dignissim ac nec tellus. Nam pretium rutrum",
         "vulputate. In risus ipsum, tempor pulvinar laoreet vel, fermentum a lectus.",
         "Sed eleifend iaculis nibh."]


class HomePage(Page):
    def __init__(self, master, app):
        super().__init__(master)
        self.header = HeaderBar(self, "STUDY PLANNER")
        self.header.place(relx=0, rely=0, relwidth=1, relheight=HEADER_H / BASE_H)

        self.intro = ctk.CTkLabel(self, text="", fg_color="transparent")
        self.intro.place(relx=0.5, rely=192 / BASE_H, anchor="n")

        self.cards = []
        for key, icon, icon_size, gap, lines, rect, _ in MENU:
            card = CardButton(self, icon, icon_size, gap, lines, command=lambda k=key: app.show_page(k))
            place_rect(card, *rect)
            self.cards.append(card)

    def rescale(self, s, ppu):
        super().rescale(s, ppu)
        self.header.rescale(s, ppu)
        intro = render_text(LOREM, "SemiBold", 23 * ppu, 0.133, C.text_dark, line_height=29 / 23, align="center")
        self.intro.configure(image=to_ctk_image(intro, ppu / s))
        for card in self.cards:
            card.rescale(s, ppu)


class SubPage(Page):
    """Placeholder page opened by a menu button - fill in with the real feature later."""

    def __init__(self, master, app, title):
        super().__init__(master)
        self.header = HeaderBar(self, title, on_back=lambda: app.show_page("home"))
        self.header.place(relx=0, rely=0, relwidth=1, relheight=HEADER_H / BASE_H)
        self.note = ctk.CTkLabel(self, text="", fg_color="transparent")
        self.note.place(relx=0.5, rely=0.45, anchor="center")

    def rescale(self, s, ppu):
        super().rescale(s, ppu)
        self.header.rescale(s, ppu)
        note = render_text(["This page is ready to be built.", "Click BACK or press Esc to return."],
                           "Medium", 20 * ppu, 0.07, C.text_dark, line_height=1.5, align="center")
        self.note.configure(image=to_ctk_image(note, ppu / s))


# --------------------------------------------------------------------------- app
class App(ctk.CTk):
    def __init__(self):
        super().__init__(fg_color=C.bg)
        self.title("Study Planner")
        self._set_initial_geometry()
        self.minsize(760, 640)

        container = ctk.CTkFrame(self, fg_color=C.bg, corner_radius=0)
        container.pack(fill="both", expand=True)
        container.grid_rowconfigure(0, weight=1)
        container.grid_columnconfigure(0, weight=1)

        self.pages = {"home": HomePage(container, self)}
        for key, *_, title in MENU:
            self.pages[key] = SubPage(container, self, title)
        for page in self.pages.values():
            page.grid(row=0, column=0, sticky="nsew")

        self.scale = 0.0
        self._after_id = None
        self.current = "home"
        self.bind("<Configure>", self._on_configure)
        self.bind("<Escape>", lambda _e: self.show_page("home"))
        self.show_page("home")
        self.after(30, self._apply_scale)

    # -- navigation (this is what the buttons call)
    def show_page(self, key: str):
        self.current = key
        page = self.pages[key]
        if page.applied_scale != self.scale and self.scale:
            page.rescale(self.scale, self.scale * self._dpi())
        page.tkraise()

    # -- sizing
    def _dpi(self) -> float:
        """OS display scaling (1.0 = 100%, 1.5 = 150% ...), as CustomTkinter sees it."""
        try:
            return ctk.ScalingTracker.get_window_scaling(self)
        except AttributeError:                       # older CustomTkinter versions
            return self._get_window_scaling()

    def _set_initial_geometry(self):
        """Open at the sample's size, or shrink (same aspect ratio) if the screen is smaller."""
        dpi = self._dpi()
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        k = min(1.0, (sw / dpi - 40) / BASE_W, (sh / dpi - 140) / BASE_H)
        w, h = round(BASE_W * k), round(BASE_H * k)
        x, y = int((sw - w * dpi) / 2), max(0, int((sh - h * dpi) / 2) - 30)
        self.geometry(f"{w}x{h}+{x}+{y}")

    def _on_configure(self, event):
        if event.widget is self:                      # ignore events bubbling up from children
            if self._after_id:
                self.after_cancel(self._after_id)
            self._after_id = self.after(40, self._apply_scale)   # debounce while dragging

    def _apply_scale(self):
        self._after_id = None
        dpi = self._dpi()
        s = min(self.winfo_width() / dpi / BASE_W, self.winfo_height() / dpi / BASE_H)
        if s <= 0 or abs(s - self.scale) < 0.004:
            return
        self.scale = s
        self.pages[self.current].rescale(s, s * dpi)   # other pages update when first shown


if __name__ == "__main__":
    if not (FONT_DIR / "Barlow-Medium.ttf").exists():
        raise SystemExit(f"Barlow fonts not found in {FONT_DIR}\n"
                         "Place study_planner.py inside the StudyPlanner folder.")
    ctk.set_appearance_mode("light")
    App().mainloop()
