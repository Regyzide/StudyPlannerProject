import mysql.connector as mcon
from pathlib import Path

# <project folder>/Entries/mysqlData.txt, found from this file's own location, so the project folder can be moved anywhere
handle = open(Path(__file__).resolve().parent / "Entries" / "mysqlData.txt" , 'r')

INITIALS = handle.readlines()[1].split(';')
TABLE_NAMES = ["SST", "Sessions", "Schedules", "Accounts", "Subjects"] #fIRST TABLE, SECOND TABLE, THIRD TABLE

conn = mcon.connect(host = 'localhost', user = INITIALS[0], password = INITIALS[1], database = INITIALS[2])
cur = conn.cursor()      

try:
 
    cur.execute(f"Create table {TABLE_NAMES[0]}(TestID int(5) primary key,"\
                "Username varchar(30) not null,"\
                    "TestName varchar(30) not null,"\
                        "Subject varchar(30) not null,"\
                            "TestDate date,"\
                                "UserMarks int(3) not null,"\
                                    "MaxMarks int(3) not null)")

    cur.execute(f"Create table {TABLE_NAMES[1]}(SessionId int(6) primary key,"\
                "Username varchar(30) not null,"\
                    "Subject varchar(30) not null,"\
                        "SessionDate date not null,"\
                            "Status int(1),"\
                                "SessionTime varchar(10))")

    cur.execute(f"Create table {TABLE_NAMES[2]}(ScheduleId int(6) primary key,"\
                "Username varchar(30) not null,"\
                    "Subject varchar(30) not null,"\
                        "ScheduledTime varchar(15) not null,"\
                            "ScheduledDate date not null,"\
                                "Remarks varchar(500))")

    cur.execute(f"Create table {TABLE_NAMES[3]}(Username varchar(30) primary key,"\
                "Password varchar(30) not null)")

    cur.execute(f"Create table {TABLE_NAMES[4]}(Username varchar(30) not null,"\
                "SubjectName varchar(30) not null,"\
                    "primary key (Username, SubjectName))")

finally:
    conn.close()



            