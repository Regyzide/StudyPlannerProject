"""
Controller: the glue between the front end (FrontEnd/) and the back end (BackEnd/).

Neither side imports the other. Only this file knows both:

    front end  --emit("login", user, password)-->  glue function  --calls-->  back end function
    front end  <------------- reply --------------  glue function  <--returns-- back end function

* A glue function receives the data the front end announced, passes it to a back end function,
  and RETURNS whatever the back end answers. The front end gets that answer back from `app.emit`.
* To add another glue function: write it below, then add one line to GLUE.
* Run the whole program with:   python main.py
* Each glue is essentially constructor overloading OOP concept ; i.e it can be used in many different places by varying types of arguements and number of arguements passed
"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "FrontEnd"))        # so the front end's own imports work
sys.path.insert(0, str(ROOT / "BackEnd"))         # so `connector.account_log` can be imported
sys.path.insert(0, str(ROOT / "BackEnd" / "connector"))   # so the files in connector/ can import each other (`from dblink import Connector`)

from connector import account_log, schedule_log, subject_log, test_log, timer_log      # back end
from planner.normalize import Normalizer                                               # study time recommendation
from planner.target_optimize import Target_Optimizer                                   # study time for a target percentage


# --------------------------------------------------------------------------- glue functions
def signup_glue(username, password):
    """Front end -> back end: SIGN-UP was pressed on the sign-up page (a NEW account).

    username, password : str  exactly what the user typed.
    Returns what account_log.receive_login() returns (it stores the new pair in the database):
    None (accept) or {"ok": False, "message": "..."} (reject, e.g. username taken).
    When the account is accepted, the preset subject (English) is added once with subject_log.Subject_Preset().
    """
    reply = account_log.receive_login(username, password)
    if not (isinstance(reply, dict) and reply.get("ok") is False):
        subject_log.Subject_Preset(username)
    return reply


def login_glue(username, password):
    """Front end -> back end: SIGN-IN was pressed on the log-in page (an EXISTING account).

    Calls account_log.authenticate(username, password). It must return {"ok": True} when the
    username/password match the Accounts table, else {"ok": False, "message": "..."}.
    The front end only lets people in on an explicit {"ok": True}.
    """
    authenticate = getattr(account_log, "authenticate", None)
    if authenticate is None:
        return {"ok": False, "message": "account_log.authenticate() is not written yet"}
    return authenticate(username, password)


def timer_glue(username, subject, session_time):
    """Front end -> back end: the timer's reset button was hit.

    username     : str    the logged-in user (set by the login / sign-up page)
    subject      : str    the subject selected on the timer page
    session_time : float  the seconds the timer showed when reset was hit
    Returns timer_log.Set_Detail()'s status: 1 = the schedule for that subject and day is now complete
    (the dashboard hides it), 0 = not complete. A failure in the database is reported in the terminal
    by the front end and counts as 0.
    """
    return timer_log.Set_Detail(username, subject, session_time)


def schedule_glue(username, subject, scheduledtime, scheduleddate, remarks):
    """Front end -> back end: the Schedule button was pressed on the scheduler page.

    username      : str  the logged-in user
    subject       : str  the subject chosen on the scheduler page
    scheduledtime : str  'HH.MM.SS' typed by the user
    scheduleddate : str  'YYYY/MM/DD' or 'YYYY-MM-DD' typed by the user
    remarks       : str  what the user typed, or "No remarks" if the box was left empty
    Stores the schedule with schedule_log.Schedule_Entry().
    """
    return schedule_log.Schedule_Entry(username, subject, scheduledtime, scheduleddate, remarks)


def test_glue(username, subject, testname, testdate, usermarks, maxmarks):
    """Front end -> back end: the Add button was pressed on the add marks page.

    username  : str  the logged-in user
    subject   : str  the subject chosen on the page
    testname  : str  test number / name (at most 30 characters)
    testdate  : str  'YYYY/MM/DD' or 'YYYY-MM-DD'
    usermarks : int  the marks the user scored   (the part before the / in "42/50")
    maxmarks  : int  the marks available         (the part after the /)
    Stores the result in the SST table with test_log.Test_Entry().
    """
    return test_log.Test_Entry(username, subject, testname, testdate, usermarks, maxmarks)


def normalize_glue(username, subject):
    """Front end -> back end: the Normalize button was pressed on the scheduler page.

    username : str  the logged-in user
    subject  : str  the subject chosen in the scheduler's dropdown
    Makes a planner.normalize.Normalizer for them and returns (time, remarks): the suggested study time
    as 'HH.MM.SS' (Normalizer.Time_Suggestion() is in seconds) and Normalizer.Remarks().
    When there isn't enough data (no tests / no sessions) it returns {"ok": False, "message": "..."}.
    """
    try:
        planner = Normalizer(username, subject)
    except ValueError as problem:
        return {"ok": False, "message": str(problem)}
    seconds = round(planner.Time_Suggestion())
    return f"{seconds // 3600:02d}.{seconds % 3600 // 60:02d}.{seconds % 60:02d}", planner.Remarks()


def optimize_glue(username, subject, percent):
    """Front end -> back end: the Optimize button was pressed on the scheduler page.

    username : str    the logged-in user
    subject  : str    the subject chosen in the scheduler's dropdown
    percent  : float  the target percentage typed in the Target % box (0 - 100)
    Makes a planner.target_optimize.Target_Optimizer for them and returns (time, remarks): the study time
    that aims for that percentage as 'HH.MM.SS' (Time_Suggestion() is in seconds) and Remarks().
    When there isn't enough data (no tests / no sessions) it returns {"ok": False, "message": "..."}.
    """
    try:
        planner = Target_Optimizer(username, subject, percent)
    except ValueError as problem:
        return {"ok": False, "message": str(problem)}
    seconds = max(0, round(planner.Time_Suggestion()))
    return f"{seconds // 3600:02d}.{seconds % 3600 // 60:02d}.{seconds % 60:02d}", planner.Remarks()


def schedule_list_glue(username):
    """Front end -> back end: the dashboard needs this user's incomplete schedules.

    Returns schedule_log.Schedule_List(): a tuple of rows (subject, date, time assigned, remarks), one per
    schedule that has no completed (status 1) session yet. It fills the dashboard's schedule table.
    """
    return schedule_log.Schedule_List(username)


def schedule_done_glue(username, subject):
    """Front end -> back end: the dashboard's third page needs one subject's completed schedules.

    Returns schedule_log.Schedule_Completed(): a tuple of rows (subject, date, time assigned, remarks), one per
    schedule that has been paid off by study time. It fills the dashboard's completed schedules table.
    """
    return schedule_log.Schedule_Completed(username, subject)


def test_list_glue(username, subject):
    """Front end -> back end: the dashboard's second page needs one subject's tests for this user.

    Returns test_log.Test_List(): a tuple of rows (subject, testname, testdate, usermarks, maxmarks) read
    from the SST table. It fills the dashboard's test table.
    """
    return test_log.Test_List(username, subject)


def subject_graph_glue(username):
    """Front end -> back end: the dashboard's left chart needs this user's best subjects.

    Returns test_log.Subject_Graph(): ((subject, percentage), ...), the top three, highest first.
    """
    return test_log.Subject_Graph(username)


def test_graph_glue(username):
    """Front end -> back end: the dashboard's right chart needs this user's best tests.

    Returns test_log.Test_Graph(): ((testname, percentage), ...), the top three, highest first.
    """
    return test_log.Test_Graph(username)


def subjects_glue(username):
    """Front end -> back end: load this user's subjects (after login / sign-up, and after every change).

    Returns the list of subject names from subject_log.Subject_List(); it fills every subject drop-down.
    """
    return subject_log.Subject_List(username)


def subject_add_glue(username, subject):
    """Front end -> back end: the + button was pressed on the manage subjects page."""
    return subject_log.Subject_Entry(username, subject)


def subject_remove_glue(username, subject):
    """Front end -> back end: a red remove button was pressed on the manage subjects page."""
    return subject_log.Subject_Remove(username, subject)


# event name the front end emits  ->  glue function that handles it
GLUE = {"signup": signup_glue, "login": login_glue, "timer_reset": timer_glue, "schedule": schedule_glue,
        "normalize": normalize_glue, "optimize": optimize_glue,
        "test": test_glue, "schedule_list": schedule_list_glue, "schedule_done": schedule_done_glue, "test_list": test_list_glue, "subject_graph": subject_graph_glue,
        "test_graph": test_graph_glue, "subjects": subjects_glue, "subject_add": subject_add_glue,
        "subject_remove": subject_remove_glue}


def connect(app):
    """Register every glue function on the app."""
    for event, function in GLUE.items():
        app.on(event, function)


# --------------------------------------------------------------------------- start the program
if __name__ == "__main__":
    import customtkinter as ctk
    from config import FONT_DIR
    from app import App

    if not (FONT_DIR / "Barlow-Medium.ttf").exists():
        raise SystemExit(f"Barlow fonts not found in {FONT_DIR}")
    ctk.set_appearance_mode("dark")
    app = App()
    connect(app)
    app.mainloop()
